<?php

namespace weatherpi\expressionMeaningLanguage;

use \weatherpi\what\What001;
use \weatherpi\weatherpiTrait\Expression_privateTrait;
use \weatherpi\weatherpiTrait\Set_expression4Trait;
use \weatherpi\weatherpiTrait\Language_privateTrait;
use \weatherpi\weatherpiTrait\Set_language4Trait;
use \weatherpi\language\Language01;
use \weatherpi\expressionMeaning\ExpressionMeaning01;
use \weatherpi\weatherpiTrait\MeaningId_privateTrait;
use \weatherpi\weatherpiTrait\Get_meaningId2Trait;

class ExpressionMeaningLanguage01 extends What001 {
  use Expression_privateTrait;
  use Set_expression4Trait;
  use Language_privateTrait;
  use Set_language4Trait;
  use MeaningId_privateTrait;
  use Get_meaningId2Trait;
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $sql = 'Select EML1T1.id As id, EMT1.meaning As meaningId From ExpressionMeaningLanguage1Table As EML1T1
    Inner Join ExpressionMeaningTable As EMT1
    On EML1T1.expressionMeaning = EMT1.id
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Inner Join LanguageTable As LT1
    On EML1T1.language = LT1.id
    Inner Join ExpressionMeaningTable As EMT2
    On LT1.name = EMT2.meaning
    Inner Join WritingSystemExpressionTable As WSET2
    On EMT2.expression = WSET2.id
    Where WSET1.expression = :expression And WSET2.expression = :language Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['expression' => $this->expression, 'language' => $this->language]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id, $meaningId){$this->meaningId = (int)$meaningId; return $id;});
    return $result;
  }

  private function create_newData()
  {
    $language = new Language01();
    $language->set_name4($this->language);
    $language->set_pdo0001($this->pdo);
    $languageId = $language->create_data();
    $expressionMeaningId = $language->get_expressionMeaningId2();
    if($this->expression != $this->language) {
        $expressionMeaning = new ExpressionMeaning01();
        $expressionMeaning->set_expression4($this->expression);
        $expressionMeaning->set_pdo0001($this->pdo);
        $expressionMeaningId = $expressionMeaning->create_data();
        $this->meaningId = $expressionMeaning->get_meaningId2();
    }
    $sql = 'Insert Into ExpressionMeaningLanguage1Table (id, expressionMeaning, language) Values (:id, :expressionMeaning, :language);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'expressionMeaning' => $expressionMeaningId, 'language' => $languageId]);
    return $this->topNodeTableId;
  }

}
