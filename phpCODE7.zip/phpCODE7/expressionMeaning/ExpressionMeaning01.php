<?php

namespace weatherpi\expressionMeaning;

use \weatherpi\what\What001;
use \weatherpi\weatherpiTrait\Expression_privateTrait;
use \weatherpi\weatherpiTrait\Set_expression4Trait;
use \weatherpi\meaning\Meaning01;
use \weatherpi\expression\Expression03;
use \weatherpi\weatherpiTrait\Get_meaningId2Trait;
use \weatherpi\weatherpiTrait\Set_meaningId2Trait;
use \weatherpi\weatherpiTrait\MeaningId_privateTrait;

class ExpressionMeaning01 extends What001 {
  use Expression_privateTrait;
  use Set_expression4Trait;
  use Get_meaningId2Trait;
  use Set_meaningId2Trait;
  use MeaningId_privateTrait;
  public function create_data()
  {
    $expression = new Expression03();
    $expression->set_expression4($this->expression);
    $expression->set_pdo0001($this->pdo);
    $meaning = new Meaning01();
    $meaning->set_pdo0001($this->pdo);
    $this->meaningId = (int)$meaning->create_data();
    $sql = 'Insert Into ExpressionMeaningTable (id, expression, meaning) Values (:id, :expression, :meaning);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'expression' => (int)$expression->create_data(), 'meaning' => $this->meaningId]);
    return $this->topNodeTableId;
    /*
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
    */
  }

  public function does_exist()
  {
    $sql = 'Select EMT1.id as id, EMT1.meaning as meaningId From ExpressionMeaningTable As EMT1
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Where WSET1.expression = :expression Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['expression' => $this->expression]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id, $meaningId){ $this->meaningId = (int)$meaningId; return $id;});
    return $result;
  }

  private function create_newData()
  {
    $meaning = new Meaning01();
    $meaning->set_pdo0001($this->pdo);
    $this->meaningId = (int)$meaning->create_data();
    $expression = new Expression03();
    $expression->set_expression4($this->expression);
    $expression->set_pdo0001($this->pdo);
    $sql = 'Insert Into ExpressionMeaningTable (id, expression, meaning) Values (:id, :expression, :meaning);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'expression' => (int)$expression->create_data(), 'meaning' => $this->meaningId]);
    return $this->topNodeTableId;
  }

  public function create_data_with_meaningId2(int $meaningId2)
  {
  }

  public function create_data_with_meaningId()
  {
    if(!empty($id = $this->does_exist_with_meaningId())) {
        return $id[0];
    }
    $expression = new Expression03();
    $expression->set_expression4($this->expression);
    $expression->set_pdo0001($this->pdo);
    $sql = 'Insert Into ExpressionMeaningTable (id, expression, meaning) Values (:id, :expression, :meaning);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'expression' => (int)$expression->create_data(), 'meaning' => $this->meaningId]);
    return $this->topNodeTableId;
  }

  private function does_exist_with_meaningId()
  {
    $sql = 'Select EMT1.id as id From ExpressionMeaningTable As EMT1
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Where WSET1.expression = :expression And EMT1.meaning = :meaning Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['expression' => $this->expression, 'meaning' => $this->meaningId]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){ return $id;});
    return $result;
  }

}
