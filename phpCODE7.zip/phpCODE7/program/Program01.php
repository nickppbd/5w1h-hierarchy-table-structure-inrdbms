<?php

namespace weatherpi\program;

use \weatherpi\weather\Weather06;
use \weatherpi\topNode\TopNode02;
use \weatherpi\weatherpiPDO\PDO01;
use \weatherpi\weather\Weather07;
use \weatherpi\schedule\Schedule01;
use \weatherpi\weatherpiTrait\Result_privateTrait;

class Program01 extends TopNode02 {
  use Result_privateTrait;
  public function start()
  {
    $this->pdo = new PDO01("mysql:host=" . 'localhost' . ";dbname=" . 'TinyOneWaterDrop4', 'weatherpi', 'Maspire1L.');
    $this->pdo->setAttribute( \PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION );
    
    $schedule = new Schedule01();
    $schedule->set_timeToStart2(strtotime("now"));
    $schedule->set_location4('seoul');
    $schedule->set_functionName4('get_openweathermap_current_weather');
    $schedule->set_endedTime3(-1);
    $schedule->set_result4('to do');
    $schedule->set_pdo0001($this->pdo);
    $result = $schedule->create_data();
    var_dump($result);
    $schedule->set_timeToStart2(strtotime("now"));
    $schedule->set_location4('beijing');
    $result = $schedule->create_data();
    var_dump($result); 
    $schedule->set_location4('tokyo');
    $schedule->set_timeToStart2(strtotime("now"));
    $result = $schedule->create_data();
    var_dump($result);
    
    $schedule->set_timeToStart2(strtotime("now"));
    $schedule->set_location4('seoul');
    $schedule->set_functionName4('get_openweathermap_forecast_weather');
    $result = $schedule->create_data();
    var_dump($result); 
    $schedule->set_timeToStart2(strtotime("now"));
    $schedule->set_location4('beijing');
    $result = $schedule->create_data();
    var_dump($result); 
    $schedule->set_timeToStart2(strtotime("now"));
    $schedule->set_location4('tokyo');
    $result = $schedule->create_data();
    var_dump($result); 
    $schedule->set_timeToStart2(strtotime("now"));
    $schedule->set_location4('seoul');
    $schedule->set_functionName4('get_yahoo_weather');
    $result = $schedule->create_data();
    var_dump($result);
    $schedule->set_timeToStart2(strtotime("now"));
    $schedule->set_location4('beijing');
    $result = $schedule->create_data();
    var_dump($result);
    $schedule->set_timeToStart2(strtotime("now"));
    $schedule->set_location4('tokyo');
    $result = $schedule->create_data();
    var_dump($result);
    $schedule->set_endedTime3(0);
    $schedule->set_result4('null');
    while(true){
        $this->pdo = new PDO01("mysql:host=" . 'localhost' . ";dbname=" . 'TinyOneWaterDrop4', 'weatherpi', 'Maspire1L.');
        $this->pdo->setAttribute( \PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION );
        $schedule->set_pdo0001($this->pdo);
        echo '-----------------new while roof------------------';
        if(empty($id = $schedule->set_to_do_data_from_db())) {
            echo 'no schedule';
            exit;  
        }
        var_dump($schedule);
        $functionName = $schedule->get_functionName4();
        $timeToStart = $schedule->get_timeToStart2();
        echo '-----------------timeToStart:';
        echo $timeToStart; 
        //$timeToStart = strtotime("now") + 3;
        $forkAfterThisTime = $timeToStart - strtotime("now");
        echo '-----------------forkAfterThisTime:';
        var_dump($forkAfterThisTime);
        if($forkAfterThisTime <= 0){
            sleep(2);
        } else if ($forkAfterThisTime > 5) {
            sleep(5);
            continue;
        } else {
            sleep($forkAfterThisTime);
        }
        $schedule->set_result4('fetched');
        $schedule->set_endedTime3(microtime(true));
        $schedule->update_endedTime_and_result_data();
        $pid = pcntl_fork();
        pcntl_wait($status);
        if (!$pid) {
            //echo $schedule->get_location4();
            echo 'I am child ';
            $this->$functionName($schedule->get_location4());
            $schedule->set_result4($this->result);
            $schedule->set_endedTime3(microtime(true));
            $schedule->update_endedTime_and_result_data();
            $schedule->set_result4('created test');
            echo ' -------------------before-------------------------- ';
            var_dump($forkAfterThisTime);
            if($this->result =='created test') {
                $schedule->set_differenceBetweentTmeToStart2(10);
                $schedule->read_averageDifferenceBetweentTmeToStart_or_more_differenceBetweentTmeToStart();
                var_dump($schedule->get_averageDifferenceBetweentTmeToStart3() == null ? 'No difference' : $schedule->get_averageDifferenceBetweentTmeToStart3());
                $time = rand(10, $schedule->get_averageDifferenceBetweentTmeToStart3() == null ? 20 : $schedule->get_averageDifferenceBetweentTmeToStart3());
                //$sample_class2->set_time($time);
            } else {
                $schedule->read_lastDifferenceBetweentTmeToStart();
                //$lastAverageTimeBetweenCreated = $schedule->get_averageDifferenceBetweentTmeToStart3();
                $schedule->read_averageDifferenceBetweentTmeToStart_or_more_differenceBetweentTmeToStart();
                var_dump($schedule->get_averageDifferenceBetweentTmeToStart3() == null ? 'No difference' : $schedule->get_averageDifferenceBetweentTmeToStart3());
                if($schedule->get_averageDifferenceBetweentTmeToStart3() == null){
                    $time = rand(10, 20);
                    //$sample_class2->set_time($time);
                } else {
                    $schedule->read_maxEndedTime();
                    $lastEndedTimeCreated = $schedule->get_endedTime3();
                    //var_dump($sample_class2->set_time());
                    //$time = $schedule->get_averageDifferenceBetweentTmeToStart3() - $sample_class2->set_time();
                    //$time = $schedule->get_averageDifferenceBetweentTmeToStart3() + $lastEndedTimeCreated - strtotime("now");
                    $time = $schedule->get_averageDifferenceBetweentTmeToStart3() - (strtotime("now") - $lastEndedTimeCreated);
                    $time =  $time < 10 ? rand(10, 20) : $time;
                    //$sample_class2->set_time($time);
                }
            }
            echo ' --------------------------------------------- ';
            var_dump($time);
            //var_dump($sample_class2->set_time());
            $schedule->set_timeToStart2(strtotime("now") + $time);
            //$l = $timeToStart + $time;
            //$l = $l <microtime(true) ? $l+50 : $l;
            //$schedule->set_timeToStart2($l);
            echo ' --------------------------------------------- ';
            //var_dump($l);
            $schedule->set_endedTime3(-1);
            $schedule->set_result4('to do');
            $schedule->create_data();
            exit();
        }
    }
  }

  public function get_openweathermap_forecast_weather( $city)
  {
    $json = file_get_contents('http://api.openweathermap.org/data/2.5/forecast?q='.$city.'&units=metric&appid=43c74349e76de681301cecdfed53a49e');
    if ($json === FALSE) {
        exit;
    }
    $openweathermapData = json_decode($json);
    $openweathermapWeatherListArray = $openweathermapData->list;
    $notCreated = false;
    $created = false;
    $rollback = false;
    foreach($openweathermapWeatherListArray as $openweathermapWeatherListElement){
        $openweathermapWeatherArray = $openweathermapWeatherListElement->weather;
        foreach($openweathermapWeatherArray as $openweathermapWeather){
        /*
        ar_dump($openweathermapWeather->main);
        var_dump($openweathermapWeather->description);
        var_dump($openweathermapWeatherListElement->main->temp);
        var_dump($openweathermapWeatherListElement->main->feels_like);
        var_dump($openweathermapWeatherListElement->main->temp_min);
        var_dump($openweathermapWeatherListElement->main->temp_max);
        var_dump($openweathermapWeatherListElement->main->pressure);
        var_dump($openweathermapWeatherListElement->main->humidity);
        var_dump($openweathermapWeatherListElement->visibility);
        var_dump($openweathermapWeatherListElement->wind->speed);
        var_dump($openweathermapWeatherListElement->wind->deg);
        var_dump($openweathermapWeatherListElement->clouds->all);
        var_dump($openweathermapWeatherListElement->dt);
        */
        $weather = new Weather06();
        $weather->set_provider4('openweathermap');
        $weather->set_time2($openweathermapWeatherListElement->dt);
        $weather->set_location4($city);
        $weather->set_type4('forecast');
        $weather->set_description4($openweathermapWeather->main);
        $weather->set_temperature3($openweathermapWeatherListElement->main->temp);
        $weather->set_humidity2($openweathermapWeatherListElement->main->humidity);
        $weather->set_pdo0001($this->pdo);
        if(!empty($id = $weather->does_exist())) {
            $notCreated  = 'not created test';
            echo $city.' forecast exist';
            var_dump($id[0]);
            //return $id[0];    
        } else {
            echo $city.' forecast new';
            try {
                $this->pdo->beginTransaction();
                $id = $weather->create_newData();
                $this->pdo->commit();
                $created = 'created test';
            } catch(PDOException $e) {
                $this->pdo->rollback();
                $rollback = 'rollback test';
                echo "Error: " . $e->getMessage();
            }
            var_dump($id);
            //return $id;
        }
        }
    }
    if($notCreated) {
        $this->result = $notCreated;
    }
    if($rollback) {
        $this->result += ' '.$rollback;
    }
    if($created){
        $this->result = $created;
    }
  }

  public function get_openweathermap_current_weather( $city)
  {
    $json = file_get_contents('http://api.openweathermap.org/data/2.5/weather?q='.$city.'&units=metric&appid=43c74349e76de681301cecdfed53a49e');
    if ($json === FALSE) {
        exit;
    }
    $openweathermapData = json_decode($json);
    $openweathermapWeatherArray = $openweathermapData->weather;
    $notCreated = false;
    $created = false;
    $rollback = false;
    foreach($openweathermapWeatherArray as $openweathermapWeather){
        /*
        var_dump($openweathermapWeather->main);
        var_dump($openweathermapWeather->description);
        var_dump($openweathermapData->main->temp);
        var_dump($openweathermapData->main->feels_like);
        var_dump($openweathermapData->main->temp_min);
        var_dump($openweathermapData->main->temp_max);
        var_dump($openweathermapData->main->pressure);
        var_dump($openweathermapData->main->humidity);
        var_dump($openweathermapData->visibility);
        var_dump($openweathermapData->wind->speed);
        var_dump($openweathermapData->wind->deg);
        var_dump($openweathermapData->clouds->all);
        var_dump($openweathermapData->dt);
        */
        $weather = new Weather06();
        $weather->set_provider4('openweathermap');
        $weather->set_time2($openweathermapData->dt);
        $weather->set_location4($city);
        $weather->set_type4('current');
        $weather->set_description4($openweathermapWeather->main);
        $weather->set_temperature3($openweathermapData->main->temp);
        $weather->set_humidity2($openweathermapData->main->humidity);
        $weather->set_pdo0001($this->pdo);
        if(!empty($id = $weather->does_exist())) {
            $notCreated  = 'not created test';
            echo $city.' current exist';
            var_dump($id[0]);
            //return $id[0];    
        } else {
            echo $city.' current new';
            try {
                $this->pdo->beginTransaction();
                $id = $weather->create_newData();
                $this->pdo->commit();
                $created = 'created test';
            } catch(PDOException $e) {
                $this->pdo->rollback();
                $rollback = 'rollback test';
                echo "Error: " . $e->getMessage();
            }
            var_dump($id);
            //return $id;
        }
    }
    if($notCreated) {
        $this->result = $notCreated;
    }
    if($rollback) {
        $this->result += ' '.$rollback;
    }
    if($created){
        $this->result = $created;
    }
  }

  public function get_yahoo_weather( $city)
  {
    $url = 'https://weather-ydn-yql.media.yahoo.com/forecastrss';
    $app_id = 'aEkGzR4g';
    $consumer_key = 'dj0yJmk9TnVDUWFhaUJubzg0JnM9Y29uc3VtZXJzZWNyZXQmc3Y9MCZ4PTBk';
    $consumer_secret = '45b175ee4b62552efbc7a8ac8974ae6395d8c716';
    $query = array(
        'location' => $city,
    //    'lat' => 37.480649199999995,
    //    'lon' => 126.9015348,
        'format' => 'json',
        'u' => 'c'
    );
    $oauth = array(
        'oauth_consumer_key' => $consumer_key,
        'oauth_nonce' => uniqid(mt_rand(1, 1000)),
        'oauth_signature_method' => 'HMAC-SHA1',
        'oauth_timestamp' => time(),
        'oauth_version' => '1.0'
    );
    $base_info = self::buildBaseString($url, 'GET', array_merge($query, $oauth));
    $composite_key = rawurlencode($consumer_secret) . '&';
    $oauth_signature = base64_encode(hash_hmac('sha1', $base_info, $composite_key, true));
    $oauth['oauth_signature'] = $oauth_signature;
    $header = array(
        self::buildAuthorizationHeader($oauth),
        'Yahoo-App-Id: ' . $app_id
    );
    $options = array(
        CURLOPT_HTTPHEADER => $header,
        CURLOPT_HEADER => false,
        CURLOPT_URL => $url . '?' . http_build_query($query),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false
    );
    $ch = curl_init();
    curl_setopt_array($ch, $options);
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
    }
    curl_close($ch);
    if (isset($error_msg)) {
        exit;
    }
    print_r($response);
    $yahooData = json_decode($response);
    /*
    var_dump($yahooData->location);
    var_dump($yahooData->current_observation);
    var_dump($yahooData->forecasts);
    echo '<pre>';
    print_r($yahooData);
    echo '</pre>';
    */
    $notCreated = false;
    $created = false;
    $rollback = false;
    
    $weather = new Weather06();
    $weather->set_provider4('yahoo');
    $weather->set_time2($yahooData->current_observation->pubDate);
    $weather->set_location4($city);
    $weather->set_type4('current');
    $weather->set_description4($yahooData->current_observation->condition->text);
    $weather->set_temperature3($yahooData->current_observation->condition->temperature);
    $weather->set_humidity2($yahooData->current_observation->atmosphere->humidity);
    $weather->set_pdo0001($this->pdo);
    if(!empty($id = $weather->does_exist())) {
        $notCreated  = 'not created test';
        echo $city.' current exist';
        var_dump($id[0]);
        //return $id[0];    
    } else {
        echo $city.' current new';
        try {
            $this->pdo->beginTransaction();
            $id = $weather->create_newData();
            $this->pdo->commit();
            $created = 'created test';
        } catch(PDOException $e) {
            $this->pdo->rollback();
            $rollback = 'rollback test';
            echo "Error: " . $e->getMessage();
        }
        var_dump($id);
        //return $id;
    }
    $yahooWeatherArray = $yahooData->forecasts;
    foreach($yahooWeatherArray as $yahooWeather){
        /*
        var_dump($yahooWeather->date);
        var_dump($yahooWeather->low);
        var_dump($yahooWeather->high);
        var_dump($yahooWeather->text);
        */
        $weather = new Weather07();
        $weather->set_provider4('yahoo');
        $weather->set_time2($yahooWeather->date);
        $weather->set_location4($city);
        $weather->set_type4('forecast');
        $weather->set_description4($yahooWeather->text);
        $weather->set_lowTemperature2($yahooWeather->low);
        $weather->set_highTemperature2($yahooWeather->high);
        $weather->set_pdo0001($this->pdo);
        if(!empty($id = $weather->does_exist())) {
            $notCreated  = 'not created test';
            echo $city.' forecast exist';
            var_dump($id[0]);
            //return $id[0];    
        } else {
            echo $city.' forecast new';
            try {
                $this->pdo->beginTransaction();
                $id = $weather->create_newData();
                $this->pdo->commit();
                $created = 'created test';
            } catch(PDOException $e) {
                $this->pdo->rollback();
                $rollback = 'rollback test';
                echo "Error: " . $e->getMessage();
            }
            var_dump($id);
            //return $id;
        }
    }
    if($notCreated) {
        $this->result = $notCreated;
    }
    if($rollback) {
        $this->result += ' '.$rollback;
    }
    if($created){
        $this->result = $created;
    }
  }

  private function buildBaseString( $baseURI,  $method,  $params)
  {
    $r = array();
    ksort($params);
    foreach($params as $key => $value) {
        $r[] = "$key=" . rawurlencode($value);
    }
    return $method . "&" . rawurlencode($baseURI) . '&' . rawurlencode(implode('&', $r));
  }

  private function buildAuthorizationHeader( $oauth)
  {
    $r = 'Authorization: OAuth ';
    $values = array();
    foreach($oauth as $key=>$value) {
        $values[] = "$key=\"" . rawurlencode($value) . "\"";
    }
    $r .= implode(', ', $values);
    return $r;
  }

}
