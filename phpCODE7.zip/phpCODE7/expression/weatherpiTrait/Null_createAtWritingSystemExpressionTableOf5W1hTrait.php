<?php

namespace weatherpi\expression\weatherpiTrait;

use \weatherpi\weatherpiInterface\GetConnection_PDOInterface;

trait Null_createAtWritingSystemExpressionTableOf5W1hTrait {
  protected function createAtWritingSystemExpressionTableOf5W1h(GetConnection_PDOInterface $getPdoConnectionInterface)
  {
    $sql = 'INSERT INTO WritingSystemExpressionTable (idWritingSystemExpressionTable, writingSystemExpression) VALUES (:idWritingSystemExpressionTable, :writingSystemExpression)';
    $stmt= $getPdoConnectionInterface->pdo->prepare($sql);
    $stmt->bindValue(':idWritingSystemExpressionTable', $this->getIdTopNodeTable());
    $stmt->bindValue(':writingSystemExpression', $this->getWritingSystemExpression());
    $stmt->execute();
  }

}
