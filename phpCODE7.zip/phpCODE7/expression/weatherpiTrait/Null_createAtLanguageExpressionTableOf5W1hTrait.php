<?php

namespace weatherpi\expression\weatherpiTrait;


trait Null_createAtLanguageExpressionTableOf5W1hTrait {
  public function createAtLanguageExpressionTableOf5W1h(\weatherpi\weatherpiInterface\GetConnection_PDOInterface $getPdoConnectionInterface)
  {
  }

}
