<?php

namespace weatherpi\expression;

use \weatherpi\weatherpiTrait\Expression_privateTrait;
use \weatherpi\weatherpiTrait\Set_expression4Trait;

class Expression03 extends Expression002 {
  use Expression_privateTrait;
  use Set_expression4Trait;
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $stmt= $this->pdo->prepare('Select id From WritingSystemExpressionTable Where expression = :expression Limit 1 For Update;');
    $stmt->execute(['expression' => $this->expression]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){ return $id;});
    return $result;
  }

  private function create_newData()
  {
    $stmt= $this->pdo->prepare('Insert Into WritingSystemExpressionTable (id, expression) Values (:id, :expression);');
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'expression' => $this->expression]);
    return $this->topNodeTableId;
  }

}
