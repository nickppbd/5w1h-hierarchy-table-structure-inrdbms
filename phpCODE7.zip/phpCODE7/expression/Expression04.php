<?php

namespace weatherpi\expression;

use \weatherpi\weatherpiTrait\Expression_privateTrait;
use \weatherpi\weatherpiTrait\Set_expression4Trait;
use \weatherpi\weatherpiTrait\Language_privateTrait;
use \weatherpi\weatherpiTrait\Set_language4Trait;
use \weatherpi\weatherpiTrait\LanguageLanguage_privateTrait;
use \weatherpi\weatherpiTrait\Set_languageLanguage4Trait;

class Expression04 extends Expression002 {
  use Expression_privateTrait;
  use Set_expression4Trait;
  use Language_privateTrait;
  use Set_language4Trait;
  use LanguageLanguage_privateTrait;
  use Set_languageLanguage4Trait;
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $sql = 'Select WSET1.id As id FROM WritingSystemExpressionTable As WSET1
    Inner Join LanguageExpressionTable As LET1 
    On WSET1.id = LET1.id
    Inner Join LanguageTable As LT1
    On LET1.language = LT1.id
    Inner Join WritingSystemExpressionTable As WSET2
    On LT1.name = WSET2.id
    Where WSET1.expression =:expression And WSET2.expression = :language;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['expression' => $this->expression, 'language' => $this->language]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){ return $id;});
    return $result;
  }

  private function create_newData()
  {
    $stmt= $this->pdo->prepare('Insert Into WritingSystemExpressionTable (id, expression) Values (:id, :expression);');
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'expression' => $this->expression]);
    $stmt= $this->pdo->prepare('Insert Into LanguageExpressionTable (id, language) Values (:id, :language);');
    $stmt->execute(['id' => $this->topNodeTableId, 'language' => $this->language]);
    return $this->topNodeTableId;
  }

}
