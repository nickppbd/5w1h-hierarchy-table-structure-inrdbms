<?php

namespace weatherpi\expression;

use \weatherpi\how\How001;
use \weatherpi\weatherpiTrait\Get_sql_InsertIntoExpressionTableIdValuesIdTrait;
use \weatherpi\weatherpiTrait\Prepare_sql_and_parent_create_data_and_bindValue_and_execute_by_PDOTrait;

abstract class Expression001 extends How001 {
use Get_sql_InsertIntoExpressionTableIdValuesIdTrait {
	get_sql_InsertIntoExpressionTableIdValuesId as get_sql;
}
use Prepare_sql_and_parent_create_data_and_bindValue_and_execute_by_PDOTrait {
	prepare_sql_and_parent_create_data_and_bindValue_and_execute_by_PDO as public create_data;
}
}
