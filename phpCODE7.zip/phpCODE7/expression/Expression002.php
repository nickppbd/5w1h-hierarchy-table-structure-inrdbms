<?php

namespace weatherpi\expression;

use \weatherpi\how\How001;
use \weatherpi\weatherpiInterface\Expression0001Interface;
use \weatherpi\meaning\Meaning01;

abstract class Expression002 extends How001 implements Expression0001Interface {
  public function create_data()
  {
    $stmt= $this->pdo->prepare('Insert Into ExpressionTable (id) Values (:id);');
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId]);
  }

}
