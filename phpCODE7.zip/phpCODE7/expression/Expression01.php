<?php

namespace weatherpi\expression;

use \weatherpi\weatherpiInterface\GetConnection_PDOInterface;
use \weatherpi\weatherpiTrait\Set_expression4Trait;
use \weatherpi\weatherpiTrait\GetLanguage_stringTrait;
use \weatherpi\weatherpiTrait\SetLanguage_undefined_stringTrait;
use \weatherpi\weatherpiTrait\Get_expression4Trait;

class Expression01 extends Expression001 {
  use GetLanguage_stringTrait;
  use SetLanguage_undefined_stringTrait;
  use Get_expression4Trait;
  use Set_expression4Trait;
  protected function createAt5W1h(GetPdoConnectionInterface $getPdoConnectionInterface)
  {
    parent::create();
    $sql = 'INSERT INTO WritingSystemExpressionTable (idWritingSystemExpressionTable, writingSystemExpression) VALUES (:idWritingSystemExpressionTable, :writingSystemExpression)';
    $stmt= $getPdoConnectionInterface->pdo->prepare($sql);
    $stmt->bindValue(':idWritingSystemExpressionTable', $this->getIdTopNodeTable());
    $stmt->bindValue(':writingSystemExpression', $this->getWritingSystemExpression());
    $stmt->execute();
  }

}
