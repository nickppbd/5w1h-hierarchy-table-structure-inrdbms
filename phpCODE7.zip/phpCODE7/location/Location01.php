<?php

namespace weatherpi\location;

use \weatherpi\where\Where01;
use \weatherpi\weatherpiTrait\Name_privateTrait;
use \weatherpi\weatherpiTrait\Set_name4Trait;
use \weatherpi\expressionMeaningLanguage\ExpressionMeaningLanguage01;

class Location01 extends Where01 {
  use Name_privateTrait;
  use Set_name4Trait;
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $sql = 'Select LT1.id As id From LocationTable As LT1
    Inner Join ExpressionMeaningTable As EMT1
    On LT1.name = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Where WSET1.expression = :name Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['name' => $this->name]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){return $id;});
    return $result;
  }

  private function create_newData()
  {
    $expressionMeaningLanguage = new ExpressionMeaningLanguage01();
    $expressionMeaningLanguage->set_expression4($this->name); 
    $expressionMeaningLanguage->set_language4('english'); 
    $expressionMeaningLanguage->set_pdo0001($this->pdo);
    $expressionMeaningLanguage->create_data();
    $sql = 'Insert Into LocationTable (id, name) Values (:id, :name);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'name' => $expressionMeaningLanguage->get_meaningId2()]);
    return $this->topNodeTableId;
  }

}
