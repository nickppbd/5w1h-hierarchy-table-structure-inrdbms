<?php

namespace weatherpi\weatherpiTrait;


trait GetLanguage_stringTrait {
  public function getLanguage_string_weatherpi(): string
  {
    return $this->language;
  }

}
