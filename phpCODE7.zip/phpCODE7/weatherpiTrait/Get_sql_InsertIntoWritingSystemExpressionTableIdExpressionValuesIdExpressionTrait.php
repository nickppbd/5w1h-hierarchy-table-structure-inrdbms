<?php

namespace weatherpi\weatherpiTrait;


trait Get_sql_InsertIntoWritingSystemExpressionTableIdExpressionValuesIdExpressionTrait {
  public function get_sql_InsertIntoWritingSystemExpressionTableIdExpressionValuesIdExpression(): string
  {
    return 'Insert Into WritingSystemExpressionTable (id, expression) Values (:id, :expression)';
  }

}
