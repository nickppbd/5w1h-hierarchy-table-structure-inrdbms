<?php

namespace weatherpi\weatherpiTrait;


trait GetHost_stringTrait {
  public function getHost_string_weatherpi(): string
  {
    return $this->host;
  }

}
