<?php

namespace weatherpi\weatherpiTrait;


trait Get_result4Trait {
  public function get_result4(): string
  {
    return $this->result;
  }

}
