<?php

namespace weatherpi\weatherpiTrait;


trait Dbname_privateTrait {
  private $dbname;

}
