<?php

namespace weatherpi\weatherpiTrait;


trait Get_timeBetweenCreated3Trait {
  public function get_timeBetweenCreated3():?float
  {
    return $this->timeBetweenCreated;
  }

}
