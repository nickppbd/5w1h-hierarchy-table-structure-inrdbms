<?php

namespace weatherpi\weatherpiTrait;


trait Get_anonymousFunction_id_return_idTrait {
  private function get_anonymousFunction_id_return_id()
  {
    return function($id){ return $id;};
  }

}
