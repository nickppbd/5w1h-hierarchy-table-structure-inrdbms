<?php

namespace weatherpi\weatherpiTrait;


trait GetUsername_stringTrait {
  public function getUsername_string_weatherpi(): string
  {
  }

}
