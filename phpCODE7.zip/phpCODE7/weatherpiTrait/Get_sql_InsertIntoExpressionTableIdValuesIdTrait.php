<?php

namespace weatherpi\weatherpiTrait;


trait Get_sql_InsertIntoExpressionTableIdValuesIdTrait {
  private function get_sql_InsertIntoExpressionTableIdValuesId()
  {
    return 'Insert Into ExpressionTable (id) Values (:id)';
  }

}
