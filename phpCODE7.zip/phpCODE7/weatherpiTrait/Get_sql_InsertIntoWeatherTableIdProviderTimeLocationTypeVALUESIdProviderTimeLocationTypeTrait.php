<?php

namespace weatherpi\weatherpiTrait;


trait Get_sql_InsertIntoWeatherTableIdProviderTimeLocationTypeVALUESIdProviderTimeLocationTypeTrait {
  private function get_sql_InsertIntoWeatherTableIdProviderTimeLocationTypeVALUESIdProviderTimeLocationType()
  {
    return 'Insert Into WeatherTable (id, provider, time, location, type) VALUES (:id, :provider, :time, :location, :type)';
  }

}
