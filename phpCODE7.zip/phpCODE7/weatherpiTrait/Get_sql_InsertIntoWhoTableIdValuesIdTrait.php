<?php

namespace weatherpi\weatherpiTrait;


trait Get_sql_InsertIntoWhoTableIdValuesIdTrait {
  private function get_sql_InsertIntoWhoTableIdValuesId()
  {
    return 'Insert Into WhoTable (id) Values (:id)';
  }

}
