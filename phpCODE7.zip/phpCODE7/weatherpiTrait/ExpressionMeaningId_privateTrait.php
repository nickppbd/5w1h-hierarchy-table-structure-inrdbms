<?php

namespace weatherpi\weatherpiTrait;


trait ExpressionMeaningId_privateTrait {
  private $expressionMeaningId;

}
