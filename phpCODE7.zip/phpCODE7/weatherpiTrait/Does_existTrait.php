<?php

namespace weatherpi\weatherpiTrait;


trait Does_existTrait {
  public function does_exist()
  {
    $result = $this->prepare_sql4_and_bindValue_colonColumnName4_with_value0_and_execute_and_fetchAll_with_FUNC_by_PDO($this->get_sql_SelectIdFromWritingSystemExpressionTableWhereExpressionEqualExpressionLimit1ForUpdate(), ':expression', $this->expression, $this->get_anonymousFunction_id_return_id());
    return $result[0];
  }

}
