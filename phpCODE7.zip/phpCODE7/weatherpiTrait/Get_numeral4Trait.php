<?php

namespace weatherpi\weatherpiTrait;


trait Get_numeral4Trait {
  public function get_numeral4(): string
  {
    return $this->numeral;
  }

}
