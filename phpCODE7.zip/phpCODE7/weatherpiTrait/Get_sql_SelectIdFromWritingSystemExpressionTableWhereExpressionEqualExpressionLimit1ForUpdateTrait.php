<?php

namespace weatherpi\weatherpiTrait;


trait Get_sql_SelectIdFromWritingSystemExpressionTableWhereExpressionEqualExpressionLimit1ForUpdateTrait {
  private function get_sql_SelectIdFromWritingSystemExpressionTableWhereExpressionEqualExpressionLimit1ForUpdate()
  {
    return 'Select id From WritingSystemExpressionTable Where expression = :expression Limit 1 For Update;';
  }

}
