<?php

namespace weatherpi\weatherpiTrait;


trait Get_meaningId4Trait {
  public function get_meaningId4(): string
  {
    return $this->meaningId;
  }

}
