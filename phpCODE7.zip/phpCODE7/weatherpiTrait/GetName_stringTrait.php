<?php

namespace weatherpi\weatherpiTrait;


trait GetName_stringTrait {
  public function getName_string_weatherpi(): string
  {
    return $this->name;
  }

}
