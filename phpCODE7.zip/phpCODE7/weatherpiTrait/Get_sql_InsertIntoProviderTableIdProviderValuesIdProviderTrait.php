<?php

namespace weatherpi\weatherpiTrait;


trait Get_sql_InsertIntoProviderTableIdProviderValuesIdProviderTrait {
  private function get_sql_InsertIntoProviderTableIdProviderValuesIdProvider()
  {
    return 'Insert Into ProviderTable (id, provider) Values (:id, :provider)';
  }

}
