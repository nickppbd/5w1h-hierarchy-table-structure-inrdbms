<?php

namespace weatherpi\weatherpiTrait;


trait EpochTime_privateTrait {
  private $epochTime;

}
