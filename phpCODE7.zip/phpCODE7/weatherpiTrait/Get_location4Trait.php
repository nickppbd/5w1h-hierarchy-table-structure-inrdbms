<?php

namespace weatherpi\weatherpiTrait;


trait Get_location4Trait {
  public function get_location4(): string
  {
    return $this->location;
  }

}
