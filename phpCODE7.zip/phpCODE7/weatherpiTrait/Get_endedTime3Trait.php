<?php

namespace weatherpi\weatherpiTrait;


trait Get_endedTime3Trait {
  public function get_endedTime3(): float
  {
    return $this->endedTime;
  }

}
