<?php

namespace weatherpi\weatherpiTrait;


trait Get_averageDifferenceBetweentTmeToStart3Trait {
  public function get_averageDifferenceBetweentTmeToStart3():?float
  {
    return $this->averageDifferenceBetweentTmeToStart;
  }

}
