<?php

namespace weatherpi\weatherpiTrait;


trait Get_sql_InsertIntoWhereTableIdValuesIdTrait {
  private function get_sql_InsertIntoWhereTableIdValuesId()
  {
    return 'Insert Into WhereTable (id) Values (:id)';
  }

}
