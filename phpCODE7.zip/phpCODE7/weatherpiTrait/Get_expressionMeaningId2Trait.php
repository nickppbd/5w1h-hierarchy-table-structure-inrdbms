<?php

namespace weatherpi\weatherpiTrait;


trait Get_expressionMeaningId2Trait {
  public function get_expressionMeaningId2(): int
  {
    return $this->expressionMeaningId;
  }

}
