<?php

namespace weatherpi\weatherpiTrait;


trait GetPassword_stringTrait {
  public function getPassword_string_weatherpi(): string
  {
    return $this->password;
  }

}
