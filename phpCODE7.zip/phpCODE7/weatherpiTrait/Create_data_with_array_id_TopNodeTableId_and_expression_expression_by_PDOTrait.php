<?php

namespace weatherpi\weatherpiTrait;


trait Create_data_with_array_id_TopNodeTableId_and_expression_expression_by_PDOTrait {
  private function create_data_with_array_id_TopNodeTableId_and_expression_expression_by_PDO()
  {
    if($id = $this->does_exist()){
        return $id;
    } else {
    $this->prepare_sql_and_parent_create_data_and_execute_with_associativeArray5_by_PDO(['id' => null, 'expression' => $this->expression]);
        return $this->topNodeTableId;
    }
  }

}
