<?php

namespace weatherpi\weatherpiTrait;


trait Get_functionName4Trait {
  public function get_functionName4(): string
  {
    return $this->functionName;
  }

}
