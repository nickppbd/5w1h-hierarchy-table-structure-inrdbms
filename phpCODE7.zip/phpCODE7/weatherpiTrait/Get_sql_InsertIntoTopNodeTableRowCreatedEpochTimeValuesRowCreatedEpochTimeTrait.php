<?php

namespace weatherpi\weatherpiTrait;


trait Get_sql_InsertIntoTopNodeTableRowCreatedEpochTimeValuesRowCreatedEpochTimeTrait {
  private function get_sql_InsertIntoTopNodeTableRowCreatedEpochTimeValuesRowCreatedEpochTime()
  {
    return 'INSERT INTO TopNodeTable (rowCreatedEpochTime) VALUES (:rowCreatedEpochTime)';
  }

}
