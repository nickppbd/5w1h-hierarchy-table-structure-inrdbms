<?php

namespace weatherpi\weatherpiTrait;


trait GetDbname_stringTrait {
  public function getDbname_string_weatherpi(): string
  {
    return $this->db;
  }

}
