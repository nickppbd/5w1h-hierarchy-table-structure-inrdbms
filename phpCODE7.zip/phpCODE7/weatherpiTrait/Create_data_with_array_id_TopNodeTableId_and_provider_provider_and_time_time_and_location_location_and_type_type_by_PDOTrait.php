<?php

namespace weatherpi\weatherpiTrait;


trait Create_data_with_array_id_TopNodeTableId_and_provider_provider_and_time_time_and_location_location_and_type_type_by_PDOTrait {
  private function create_data_with_array_id_TopNodeTableId_and_provider_provider_and_time_time_and_location_location_and_type_type_by_PDO()
  {
    //$this->prepare_sql_and_parent_create_data_and_execute_with_data5_by_PDO(['id' => null, 'provider' => $this->provider->create_data(), 'time' => $this->time->create_data(), 'location' => $this->location->create_data(), 'type' => $this->type->create_data()]);
    $this->prepare_sql_and_parent_create_data_and_execute_with_associativeArray5_by_PDO(['id' => null, 'provider' => $this->provider->create_data(), 'time' => '18', 'location' => '19', 'type' => '17']);
  }

}
