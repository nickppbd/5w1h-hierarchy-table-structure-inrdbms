<?php

namespace weatherpi\weatherpiTrait;


trait Expression_privateTrait {
  private $expression;

}
