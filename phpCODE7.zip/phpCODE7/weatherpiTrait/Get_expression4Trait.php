<?php

namespace weatherpi\weatherpiTrait;


trait Get_expression4Trait {
  public function get_expression4_weatherpi(): string
  {
    return $this->writingSystemExpression;
  }

}
