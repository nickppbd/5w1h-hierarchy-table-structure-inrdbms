<?php

namespace weatherpi\weatherpiTrait;

use \weatherpi\expression\Expression02;

trait Create_data_with_array_id_TopNodeTableId_and_provider_provider_by_PDOTrait {
  private function create_data_with_array_id_TopNodeTableId_and_provider_provider_by_PDO()
  {
    $expression02 = new Expression02();
    $expression02->set_expression4($this->provider);
    $expression02->set_pdo0001($this->pdo);
    $providerId = (int)$expression02->create_data();
    $this->prepare_sql_and_parent_create_data_and_execute_with_associativeArray5_by_PDO(['id' => null, 'provider' => $providerId]);
    return $this->topNodeTableId;
  }

}
