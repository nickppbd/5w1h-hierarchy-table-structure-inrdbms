<?php

namespace weatherpi\weatherpiTrait;


trait Get_meaningId2Trait {
  public function get_meaningId2(): int
  {
    return $this->meaningId;
  }

}
