<?php

namespace weatherpi\weatherpiTrait;


trait Get_timeToStart2Trait {
  public function get_timeToStart2(): int
  {
    return $this->timeToStart;
  }

}
