<?php

namespace weatherpi\weatherpiTrait;


trait Get_sql_InsertIntoWhatTableIdValuesIdTrait {
  private function get_sql_InsertIntoWhatTableIdValuesId()
  {
    return 'Insert Into WhatTable (id) Values (:id)';
  }

}
