<?php

namespace weatherpi\weatherpiTrait;


trait Connection_privateTrait {
  private $connection;

}
