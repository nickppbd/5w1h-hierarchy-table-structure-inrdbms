<?php

namespace weatherpi\weatherpiTrait;


trait Get_differenceBetweentTmeToStart2Trait {
  public function get_differenceBetweentTmeToStart2():?int
  {
    return $this->differenceBetweentTmeToStart;
  }

}
