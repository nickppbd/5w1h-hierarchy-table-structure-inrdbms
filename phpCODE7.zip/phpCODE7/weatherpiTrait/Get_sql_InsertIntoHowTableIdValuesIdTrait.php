<?php

namespace weatherpi\weatherpiTrait;


trait Get_sql_InsertIntoHowTableIdValuesIdTrait {
  private function get_sql_InsertIntoHowTableIdValuesId()
  {
    return 'Insert Into HowTable (id) Values (:id)';
  }

}
