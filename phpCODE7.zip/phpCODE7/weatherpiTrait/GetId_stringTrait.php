<?php

namespace weatherpi\weatherpiTrait;


trait GetId_stringTrait {
  public function getId_string_weatherpi(): string
  {
    return $this->Id;
  }

}
