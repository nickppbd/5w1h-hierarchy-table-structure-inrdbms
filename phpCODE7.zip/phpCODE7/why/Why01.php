<?php

namespace weatherpi\why;

use \weatherpi\topNode\TopNode01;

abstract class Why01 extends TopNode01 {
  protected function createAt5W1h(GetPdoConnectionInterface $getPdoConnectionInterface)
  {
  }

}
