<?php

namespace weatherpi\weatherpiInterface;


interface GetQueryOfInsertIntoExpressionTableidExpressionTable_stringInterface {
  public function getQueryOfInsertIntoExpressionTableidExpressionTable_string_weatherpi();
}
