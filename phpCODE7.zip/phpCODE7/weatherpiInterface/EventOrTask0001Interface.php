<?php

namespace weatherpi\weatherpiInterface;


interface EventOrTask0001Interface {
}
