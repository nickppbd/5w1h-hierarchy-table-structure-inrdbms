<?php

namespace weatherpi\weatherpiInterface;


//For SQLite
interface DatabaseAbstract_1Interface extends DatabaseAbstractInterface {
}
