<?php

namespace weatherpi\weatherpiInterface;


interface GetProviderOfWeather_stringInterface extends GetProviderAbstractInterface {
  public function getProviderOfWeather_string_Weatherpi();
}
