<?php

namespace weatherpi\weatherpiInterface;


interface Expression0001Interface extends ExpressionInterface {
}
