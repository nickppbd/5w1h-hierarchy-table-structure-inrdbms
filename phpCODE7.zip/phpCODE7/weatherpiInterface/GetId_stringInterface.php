<?php

namespace weatherpi\weatherpiInterface;


interface GetId_stringInterface extends GetIdAbstractInterface {
  public function getId_string_weatherpi(): string;
}
