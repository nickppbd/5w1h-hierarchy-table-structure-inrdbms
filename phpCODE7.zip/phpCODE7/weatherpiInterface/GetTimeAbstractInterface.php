<?php

namespace weatherpi\weatherpiInterface;


interface GetTimeAbstractInterface {
}
