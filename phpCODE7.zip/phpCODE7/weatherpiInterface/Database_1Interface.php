<?php

namespace weatherpi\weatherpiInterface;


interface Database_1Interface extends DatabaseAbstract_2Interface, GetConnectionOfMySQL_PDOInterface {
}
