<?php

namespace weatherpi\weatherpiInterface;


interface Return_expression3_property_from_obejctInterface {
  public function return_expression3_property_from_obejct_weatherpi(): string;
}
