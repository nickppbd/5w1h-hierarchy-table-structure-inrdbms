<?php

namespace weatherpi\weatherpiInterface;


interface Get_PDO01Interface {
  public function get_PDO01(): \PDO
  ;
}
