<?php

namespace weatherpi\weatherpiInterface;


interface Language0001Interface {
}
