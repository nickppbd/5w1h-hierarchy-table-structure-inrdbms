<?php

namespace weatherpi\weatherpiInterface;


interface GetQueryAbstract_1Interface extends GetQueryAbstractInterface {
}
