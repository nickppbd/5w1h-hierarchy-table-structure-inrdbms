<?php

namespace weatherpi\weatherpiInterface;


interface Id_1Interface extends IdAbstractInterface, GetId_stringInterface, SetId_undefined_stringInterface {
}
