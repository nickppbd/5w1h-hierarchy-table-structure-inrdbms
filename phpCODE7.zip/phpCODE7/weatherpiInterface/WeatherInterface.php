<?php

namespace weatherpi\weatherpiInterface;


interface WeatherInterface {
}
