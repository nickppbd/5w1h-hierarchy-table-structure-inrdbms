<?php

namespace weatherpi\weatherpiInterface;


interface GetConnection_mysqliInterface extends GetConnectionAbstractInterface {
  public function getConnection_mysqli_weatherpi(): mysqli;
}
