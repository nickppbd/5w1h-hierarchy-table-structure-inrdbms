<?php

namespace weatherpi\weatherpiInterface;


interface Name001Interface extends Get_Name1Interface {
}
