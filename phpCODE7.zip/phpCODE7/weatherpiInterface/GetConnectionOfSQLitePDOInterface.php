<?php

namespace weatherpi\weatherpiInterface;


interface GetConnectionOfSQLitePDOInterface extends GetConnection_PDOInterface, DatabaseAbstract_1Interface, GetConnectionAbstract_1Interface {
}
