<?php

namespace weatherpi\weatherpiInterface;


interface GetConnection_PDOInterface extends GetConnectionAbstractInterface {
  public function getConnection_PDO_weatherpi(): \PDO;
}
