<?php

namespace weatherpi\weatherpiInterface;


interface Get_Name1Interface {
  public function get_Name1_weatherpi(): string;
}
