<?php

namespace weatherpi\weatherpiInterface;


interface GetLocationOfWeather_stringInterface extends GetLocationAbstractInterface {
  public function GetLocationOfWeather_stringInterface();
}
