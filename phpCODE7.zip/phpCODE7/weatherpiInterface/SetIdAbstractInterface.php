<?php

namespace weatherpi\weatherpiInterface;


interface SetIdAbstractInterface {
}
