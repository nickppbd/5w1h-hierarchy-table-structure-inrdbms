<?php

namespace weatherpi\weatherpiInterface;


interface GetProviderAbstractInterface {
}
