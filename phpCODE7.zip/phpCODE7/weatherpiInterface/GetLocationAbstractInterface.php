<?php

namespace weatherpi\weatherpiInterface;


interface GetLocationAbstractInterface {
}
