<?php

namespace weatherpi\weatherpiInterface;


interface GetQueryAbstractInterface {
}
