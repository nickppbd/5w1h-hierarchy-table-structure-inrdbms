<?php

namespace weatherpi\weatherpiInterface;


interface GetConnectionAbstract_1Interface extends GetConnectionAbstractInterface {
}
