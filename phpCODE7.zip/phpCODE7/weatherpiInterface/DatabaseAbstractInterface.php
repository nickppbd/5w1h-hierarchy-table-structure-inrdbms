<?php

namespace weatherpi\weatherpiInterface;


interface DatabaseAbstractInterface {
}
