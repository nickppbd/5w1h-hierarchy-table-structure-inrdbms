<?php

namespace weatherpi\weatherpiInterface;


interface GetIdAbstractInterface {
}
