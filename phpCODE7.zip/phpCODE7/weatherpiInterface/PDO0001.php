<?php

namespace weatherpi\weatherpiInterface;


interface PDO0001 {
}
