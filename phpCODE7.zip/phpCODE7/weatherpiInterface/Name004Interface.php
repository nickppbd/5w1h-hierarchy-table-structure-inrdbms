<?php

namespace weatherpi\weatherpiInterface;


interface Name004Interface extends Name001Interface, Get_StartTime1Interface {
}
