<?php

namespace weatherpi\weatherpiInterface;


interface Get_StartTime1Interface {
  public function get_StartTime1_weatherpi(): string;
}
