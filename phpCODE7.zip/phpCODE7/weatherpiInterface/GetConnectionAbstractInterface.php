<?php

namespace weatherpi\weatherpiInterface;


interface GetConnectionAbstractInterface {
}
