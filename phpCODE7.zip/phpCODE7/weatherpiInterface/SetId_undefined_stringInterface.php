<?php

namespace weatherpi\weatherpiInterface;


interface SetId_undefined_stringInterface extends SetIdAbstractInterface {
  public function setId_undefined_string_weatherpi(string $id);
}
