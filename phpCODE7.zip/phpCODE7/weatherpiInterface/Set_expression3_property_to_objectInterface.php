<?php

namespace weatherpi\weatherpiInterface;


interface Set_expression3_property_to_objectInterface {
  public function set_expression3_property_to_object_weatherpi(string $expression3);
}
