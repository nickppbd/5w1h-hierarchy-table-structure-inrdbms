<?php

namespace weatherpi\weatherpiInterface;


interface Name002Interface extends Name001Interface, \Get_Language1Interface {
}
