<?php

namespace weatherpi\weatherpiInterface;


interface GetConnectionOfMySQL_PDOInterface extends GetConnection_PDOInterface, DatabaseAbstract_2Interface, GetConnectionAbstract_1Interface {
}
