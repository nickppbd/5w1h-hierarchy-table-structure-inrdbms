<?php

namespace weatherpi\weatherpiInterface;


interface Weather_1Interface extends WeatherAbstractInterface, GetProviderOfWeather_stringInterface, GetTimeOfWeather_stringInterface, GetLocationOfWeather_stringInterface {
}
