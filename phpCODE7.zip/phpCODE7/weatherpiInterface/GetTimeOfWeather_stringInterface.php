<?php

namespace weatherpi\weatherpiInterface;


interface GetTimeOfWeather_stringInterface extends GetTimeAbstractInterface {
  public function getTimeOfWeather_string_Weatherpi();
}
