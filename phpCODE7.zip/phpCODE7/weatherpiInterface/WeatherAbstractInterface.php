<?php

namespace weatherpi\weatherpiInterface;


interface WeatherAbstractInterface {
}
