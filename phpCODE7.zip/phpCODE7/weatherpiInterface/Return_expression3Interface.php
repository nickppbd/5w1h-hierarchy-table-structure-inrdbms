<?php

namespace weatherpi\weatherpiInterface;


interface Return_expression3Interface {
  public function return_expression3_weatherpi();
}
