<?php

namespace weatherpi\weatherpiInterface;


interface Get_Name001Interface {
  public function get_Name001_weatherpi(): Name001Interface;
}
