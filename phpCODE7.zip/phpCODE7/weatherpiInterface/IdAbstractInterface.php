<?php

namespace weatherpi\weatherpiInterface;


interface IdAbstractInterface {
}
