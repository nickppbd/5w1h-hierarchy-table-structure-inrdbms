<?php

namespace weatherpi\weatherpiInterface;


interface ExpressionInterface {
}
