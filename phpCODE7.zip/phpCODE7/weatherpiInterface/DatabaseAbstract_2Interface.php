<?php

namespace weatherpi\weatherpiInterface;


//For MySQL
interface DatabaseAbstract_2Interface extends DatabaseAbstractInterface {
}
