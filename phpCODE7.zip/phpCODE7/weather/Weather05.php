<?php

namespace weatherpi\weather;

use \weatherpi\what\What001;
use \weatherpi\weatherpiTrait\provider_protectedTrait;
use \weatherpi\weatherpiTrait\time_protectedTrait;
use \weatherpi\weatherpiTrait\location_protectedTrait;
use \weatherpi\weatherpiTrait\type_protectedTrait;
use \weatherpi\weatherpiTrait\Set_location4Trait;
use \weatherpi\weatherpiTrait\Set_type4Trait;
use \weatherpi\weatherpiTrait\Set_provider4Trait;
use \weatherpi\provider\Provider02;
use \weatherpi\epochTime\EpochTime01;
use \weatherpi\location\Location01;
use \weatherpi\expressionMeaningLanguage\ExpressionMeaningLanguage01;
use \weatherpi\weatherpiTrait\Set_time2Trait;

class Weather05 extends What001 {
  use provider_protectedTrait;
  use time_protectedTrait;
  use location_protectedTrait;
  use type_protectedTrait;
  use Set_location4Trait;
  use Set_type4Trait;
  use Set_provider4Trait;
  use Set_time2Trait;
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $sql = 'Select WT1.id As id From WeatherTable As WT1
    Inner Join ProviderTable As PT1
    On WT1.provider = PT1.id
    Inner Join ExpressionMeaningTable As EMT1
    On PT1.name = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Inner Join EpochTimeTable As ETT1
    On WT1.time = ETT1.id
    Inner Join NumberTable As NT1
    On ETT1.epochTime = NT1.id
    Inner Join ExpressionMeaningTable As EMT2
    On NT1.numeral = EMT2.meaning
    Inner Join WritingSystemExpressionTable As WSET2
    On EMT2.expression = WSET2.id
    Inner Join LocationTable As LT1
    On WT1.location = LT1.id
    Inner Join ExpressionMeaningTable As EMT3
    On LT1.name = EMT3.meaning
    Inner Join WritingSystemExpressionTable As WSET3
    On EMT3.expression = WSET3.id
    Inner Join ExpressionMeaningTable As EMT4
    On WT1.type = EMT4.meaning
    Inner Join WritingSystemExpressionTable As WSET4
    On EMT4.expression = WSET4.id
    Where WSET1.expression = :provider And WSET2.expression = :time And 
    WSET3.expression = :location And WSET4.expression = :type Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['provider' => $this->provider, 'time' => $this->time, 'location' => $this->location, 'type' => $this->type]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){return $id;});
    return $result;
  }

  private function create_newData()
  {
    $provider = new Provider02();
    $provider->set_provider4($this->provider);
    $provider->set_pdo0001($this->pdo);
    $time = new EpochTime01();
    $time->set_epochTime2($this->time);
    $time->set_pdo0001($this->pdo);
    $location = new Location01();
    $location->set_name4($this->location);
    $location->set_pdo0001($this->pdo);
    $expressionMeaningLanguage = new ExpressionMeaningLanguage01();
    $expressionMeaningLanguage->set_expression4($this->type); 
    $expressionMeaningLanguage->set_language4('english'); 
    $expressionMeaningLanguage->set_pdo0001($this->pdo);
    $expressionMeaningLanguage->create_data();
    $sql = 'Insert Into WeatherTable (id, provider, time, location, type) Values (:id, :provider, :time, :location, :type);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'provider' => $provider->create_data(),
     'time' => $time->create_data(),
     'location' => $location->create_data(),
     'type' => $expressionMeaningLanguage->get_meaningId2()]);
    return $this->topNodeTableId;
  }

}
