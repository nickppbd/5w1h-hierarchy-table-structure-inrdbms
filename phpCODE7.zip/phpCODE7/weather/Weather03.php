<?php

namespace weatherpi\weather;

use \weatherpi\weatherpiTrait\humidity_protectedTrait;
use \weatherpi\weatherpiTrait\Set_humidity3Trait;

final class Weather03 extends Weather01 {
  use humidity_protectedTrait;
  use Set_humidity3Trait;
}
