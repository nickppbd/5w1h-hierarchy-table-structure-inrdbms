<?php

namespace weatherpi\weather;

use \weatherpi\weatherpiTrait\provider_publicTrait;

class Weather02 {
  use provider_publicTrait;
}
