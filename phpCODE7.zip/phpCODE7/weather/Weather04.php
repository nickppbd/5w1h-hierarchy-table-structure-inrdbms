<?php

namespace weatherpi\weather;

use \weatherpi\weatherpiTrait\humidity_publicTrait;

class Weather04 extends Weather02 {
  use humidity_publicTrait;
}
