<?php

namespace weatherpi\weather;

use \weatherpi\weatherpiTrait\Set_humidity2Trait;
use \weatherpi\weatherpiTrait\temperature_privateTrait;
use \weatherpi\weatherpiTrait\Set_temperature3Trait;
use \weatherpi\weatherpiTrait\humidity_privateTrait;
use \weatherpi\weatherpiTrait\description_privateTrait;
use \weatherpi\weatherpiTrait\Set_description4Trait;
use \weatherpi\weatherpiTrait\Prepare_InsertIntoDescriptionWeatherTableIdDescriptionValuesIdDescription_and_execute_array_id_topNodeTableId_description_expressionMeaningLanguage01_get_meaningId2_by_PDOTrait;
use \weatherpi\weatherpiTrait\Prepare_InsertIntoTemperatureWeatherTableIdTemperatureValuesIdTtemperature_and_execute_array_id_topNodeTableId_temperature_number01_create_data_by_PDOTrait;
use \weatherpi\weatherpiTrait\Prepare_InsertIntoHumidityWeatherTableIdHumidityValuesIdHumidity_and_execute_array_id_topNodeTableId_humidity_number01_create_data_by_PDOTrait;

final class Weather06 extends Weather05 {
  use Set_humidity2Trait;
  use temperature_privateTrait;
  use Set_temperature3Trait;
  use humidity_privateTrait;
  use description_privateTrait;
  use Set_description4Trait;
use Prepare_InsertIntoDescriptionWeatherTableIdDescriptionValuesIdDescription_and_execute_array_id_topNodeTableId_description_expressionMeaningLanguage01_get_meaningId2_by_PDOTrait {
	prepare_InsertIntoDescriptionWeatherTableIdDescriptionValuesIdDescription_and_execute_array_id_topNodeTableId_description_expressionMeaningLanguage01_get_meaningId2_by_PDO as create_description_data;
}
use Prepare_InsertIntoTemperatureWeatherTableIdTemperatureValuesIdTtemperature_and_execute_array_id_topNodeTableId_temperature_number01_create_data_by_PDOTrait {
	prepare_InsertIntoTemperatureWeatherTableIdTemperatureValuesIdTtemperature_and_execute_array_id_topNodeTableId_temperature_number01_create_data_by_PDO as create_temperature_data;
}
use Prepare_InsertIntoHumidityWeatherTableIdHumidityValuesIdHumidity_and_execute_array_id_topNodeTableId_humidity_number01_create_data_by_PDOTrait {
	prepare_InsertIntoHumidityWeatherTableIdHumidityValuesIdHumidity_and_execute_array_id_topNodeTableId_humidity_number01_create_data_by_PDO as create_humidity_data;
}
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $sql = 'Select WT1.id As id From WeatherTable As WT1
    Inner Join ProviderTable As PT1
    On WT1.provider = PT1.id
    Inner Join ExpressionMeaningTable As EMT1
    On PT1.name = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Inner Join EpochTimeTable As ETT1
    On WT1.time = ETT1.id
    Inner Join NumberTable As NT1
    On ETT1.epochTime = NT1.id
    Inner Join ExpressionMeaningTable As EMT2
    On NT1.numeral = EMT2.meaning
    Inner Join WritingSystemExpressionTable As WSET2
    On EMT2.expression = WSET2.id
    Inner Join LocationTable As LT1
    On WT1.location = LT1.id
    Inner Join ExpressionMeaningTable As EMT3
    On LT1.name = EMT3.meaning
    Inner Join WritingSystemExpressionTable As WSET3
    On EMT3.expression = WSET3.id
    Inner Join ExpressionMeaningTable As EMT4
    On WT1.type = EMT4.meaning
    Inner Join WritingSystemExpressionTable As WSET4
    On EMT4.expression = WSET4.id
    Inner Join DescriptionWeatherTable As DWT1
    On WT1.id = DWT1.id
    Inner Join ExpressionMeaningTable As EMT5
    On DWT1.description = EMT5.meaning
    Inner Join WritingSystemExpressionTable As WSET5
    On EMT5.expression = WSET5.id
    Inner Join TemperatureWeatherTable As TWT1
    On WT1.id = TWT1.id
    Inner Join NumberTable As NT2
    On TWT1.temperature = NT2.id
    Inner Join ExpressionMeaningTable As EMT6
    On NT2.numeral = EMT6.meaning
    Inner Join WritingSystemExpressionTable As WSET6
    On EMT6.expression = WSET6.id
    Inner Join HumidityWeatherTable As HWT1
    On WT1.id = HWT1.id
    Inner Join NumberTable As NT3
    On HWT1.humidity = NT3.id
    Inner Join ExpressionMeaningTable As EMT7
    On NT3.numeral = EMT7.meaning
    Inner Join WritingSystemExpressionTable As WSET7
    On EMT7.expression = WSET7.id
    Where WSET1.expression = :provider And WSET2.expression = :time And 
    WSET3.expression = :location And WSET4.expression = :type And 
    WSET5.expression =:description And WSET6.expression = :temperature And 
    WSET7.expression = :humidity Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['provider' => $this->provider, 'time' => $this->time, 
    'location' => $this->location, 'type' => $this->type, 'description' => $this->description
    , 'temperature' => $this->temperature, 'humidity' => $this->humidity]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){return $id;});
    return $result;
  }

  public function create_newData()
  {
    parent::create_data();
    $this->create_description_data();
    $this->create_temperature_data();
    $this->create_humidity_data();
    return $this->topNodeTableId;
    /*
    $expressionMeaningLanguage = new ExpressionMeaningLanguage01();
    $expressionMeaningLanguage->set_expression4($this->description); 
    $expressionMeaningLanguage->set_language4('english'); 
    $expressionMeaningLanguage->set_pdo0001($this->pdo);
    $expressionMeaningLanguage->create_data();
    $number1 = new Number01();
    $number1->set_numeral0($this->temperature);
    $number1->set_pdo0001($this->pdo);
    $number2 = new Number01();
    $number2->set_numeral0($this->humidity);
    $number2->set_pdo0001($this->pdo);
    $sql1 = 'Insert Into DescriptionWeatherTable (id, description) Values (:id, :description);';
    $stmt1= $this->pdo->prepare($sql1);
    $sql2 = 'Insert Into TemperatureWeatherTable (id, temperature) Values (:id, :temperature);';
    $stmt2= $this->pdo->prepare($sql2);
    $sql3 = 'Insert Into HumidityWeatherTable (id, humidity) Values (:id, :humidity);';
    $stmt3= $this->pdo->prepare($sql3);
    
    $stmt1->execute(['id' => $this->topNodeTableId, 'description' => $expressionMeaningLanguage->get_meaningId2()]);
    $stmt2->execute(['id' => $this->topNodeTableId, 'temperature' => $number1->create_data()]);
    $stmt3->execute(['id' => $this->topNodeTableId, 'humidity' => $number2->create_data()]);
    
    */
  }

}
