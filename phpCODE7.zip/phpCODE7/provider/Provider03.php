<?php

namespace weatherpi\provider;

use \weatherpi\who\Who001;
use \weatherpi\weatherpiTrait\provider_privateTrait;
use \weatherpi\expression\Expression03;
use \weatherpi\weatherpiTrait\Set_provider0000001Trait;

class Provider03 extends Who001 {
  use provider_privateTrait;
  use Set_provider0000001Trait;
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $sql = 'Select PT1.id From TinyOneWaterDrop.ProviderTable As PT1
    Inner Join WritingSystemExpressionTable As WSET1
    On PT1.provider = WSET1.id
    Where WSET1.expression = :expression;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['expression' => $this->provider]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){ return $id;});
    return $result;
  }

  private function create_newData()
  {
    <?
    /*
    $expression = new Expression03();
    $expression->set_expression4($this->provider);
    $expression->set_pdo0001($this->pdo);
    $providerId = $expression->create_data();
    */
    $sql = 'Insert Into ProviderTable (id, provider) Values (:id, :provider);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'provider' => $this->provider->create_data()]);
    return $this->topNodeTableId;
  }

}
