<?php

namespace weatherpi\provider;

use \weatherpi\who\Who001;
use \weatherpi\weatherpiTrait\provider_privateTrait;
use \weatherpi\weatherpiTrait\Set_provider4Trait;
use \weatherpi\expression\Expression03;
use \weatherpi\weatherpiTrait\MeaningId_privateTrait;
use \weatherpi\weatherpiTrait\Get_meaningId2Trait;
use \weatherpi\expressionMeaningLanguage\ExpressionMeaningLanguage01;

class Provider02 extends Who001 {
  use provider_privateTrait;
  use Set_provider4Trait;
  use MeaningId_privateTrait;
  use Get_meaningId2Trait;
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $sql = 'Select PT1.id As id From ProviderTable As PT1
    Inner Join ExpressionMeaningTable As EMT1
    On PT1.name = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Where WSET1.expression = :provider Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['provider' => $this->provider]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){ return $id;});
    return $result;
  }

  private function create_newData()
  {
    $expressionMeaningLanguage = new ExpressionMeaningLanguage01();
    $expressionMeaningLanguage->set_expression4($this->provider); 
    $expressionMeaningLanguage->set_language4('english'); 
    $expressionMeaningLanguage->set_pdo0001($this->pdo);
    $expressionMeaningLanguage->create_data();
    $meaningId = $expressionMeaningLanguage->get_meaningId2();
    $sql = 'Insert Into ProviderTable (id, name) Values (:id, :name);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'name' => $meaningId]);
    return $this->topNodeTableId;
  }

}
