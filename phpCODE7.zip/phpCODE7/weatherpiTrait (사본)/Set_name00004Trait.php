<?php

namespace weatherpi\weatherpiTrait;


trait Set_name00004Trait {
  public function set_name00004(\weatherpi\expression\Expression04 $name00004)
  {
    $this->name = $name00004;
  }

}
