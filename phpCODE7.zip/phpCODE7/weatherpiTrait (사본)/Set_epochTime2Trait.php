<?php

namespace weatherpi\weatherpiTrait;


trait Set_epochTime2Trait {
  public function set_epochTime2(int $epochTime2)
  {
    $this->epochTime = $epochTime2;
  }

}
