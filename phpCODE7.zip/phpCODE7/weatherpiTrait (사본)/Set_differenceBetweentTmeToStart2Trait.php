<?php

namespace weatherpi\weatherpiTrait;


trait Set_differenceBetweentTmeToStart2Trait {
  public function set_differenceBetweentTmeToStart2(float $differenceBetweentTmeToStart2)
  {
    $this->differenceBetweentTmeToStart = $differenceBetweentTmeToStart2;
  }

}
