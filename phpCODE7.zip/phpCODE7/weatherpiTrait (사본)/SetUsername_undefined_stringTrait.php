<?php

namespace weatherpi\weatherpiTrait;


trait SetUsername_undefined_stringTrait {
  public function setUsername_undefined_string_weatherpi(string $username)
  {
    $this->username = $username;
  }

}
