<?php

namespace weatherpi\weatherpiTrait;


trait Set_highTemperature2Trait {
  public function set_highTemperature2(int $highTemperature2)
  {
    $this->highTemperature = $highTemperature2;
  }

}
