<?php

namespace weatherpi\weatherpiTrait;


trait Set_provider01Trait {
  public function set_provider01(\weatherpi\provider\Provider01 $provider01)
  {
    $this->provider = $provider01;
  }

}
