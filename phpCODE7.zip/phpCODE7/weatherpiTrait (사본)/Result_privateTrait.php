<?php

namespace weatherpi\weatherpiTrait;


trait Result_privateTrait {
  private $result;

}
