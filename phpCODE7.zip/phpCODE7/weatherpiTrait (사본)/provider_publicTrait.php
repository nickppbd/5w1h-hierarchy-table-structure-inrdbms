<?php

namespace weatherpi\weatherpiTrait;


trait provider_publicTrait {
  public $provider;

}
