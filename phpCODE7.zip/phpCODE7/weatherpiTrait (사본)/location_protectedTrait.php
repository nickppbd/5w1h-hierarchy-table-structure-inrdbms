<?php

namespace weatherpi\weatherpiTrait;


trait location_protectedTrait {
  protected $location;

}
