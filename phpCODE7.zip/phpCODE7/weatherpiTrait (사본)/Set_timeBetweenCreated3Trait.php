<?php

namespace weatherpi\weatherpiTrait;


trait Set_timeBetweenCreated3Trait {
  public function set_timeBetweenCreated3(float $timeBetweenCreated3)
  {
    $this->timeBetweenCreated = $timeBetweenCreated3;
  }

}
