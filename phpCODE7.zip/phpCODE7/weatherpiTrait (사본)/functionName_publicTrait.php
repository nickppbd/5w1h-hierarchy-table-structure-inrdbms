<?php

namespace weatherpi\weatherpiTrait;


//

trait functionName_publicTrait {
  public $functionName;

}
