<?php

namespace weatherpi\weatherpiTrait;


trait Prepare_sql_and_bindValue_colonColumnName4_with_value0_and_execute_and_fetchAll_with_FUNC_by_PDOTrait {
  private function prepare_sql4_and_bindValue_colonColumnName4_with_value0_and_execute_and_fetchAll_with_FUNC_by_PDO(string $sql4, string $colonColumnName4,  $value0,  $fetchArgument0): array
  {
    $stmt= $this->pdo->prepare($sql4);
    $stmt->bindValue($colonColumnName4, $value0);
    $stmt->execute();
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, $fetchArgument0);
    return $result;
  }

}
