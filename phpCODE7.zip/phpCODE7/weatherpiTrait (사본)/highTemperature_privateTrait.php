<?php

namespace weatherpi\weatherpiTrait;


trait highTemperature_privateTrait {
  private $highTemperature;

}
