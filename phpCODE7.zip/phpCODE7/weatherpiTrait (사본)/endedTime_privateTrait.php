<?php

namespace weatherpi\weatherpiTrait;


trait endedTime_privateTrait {
  private $endedTime;

}
