<?php

namespace weatherpi\weatherpiTrait;


trait Set_differenceBetweentTmeToStart3Trait {
  public function set_differenceBetweentTmeToStart3(float $differenceBetweentTmeToStart3)
  {
    $this->differenceBetweentTmeToStart = $differenceBetweentTmeToStart3;
  }

}
