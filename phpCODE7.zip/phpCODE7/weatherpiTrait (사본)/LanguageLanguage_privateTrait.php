<?php

namespace weatherpi\weatherpiTrait;


trait LanguageLanguage_privateTrait {
  private $languageLanguage;

}
