<?php

namespace weatherpi\weatherpiTrait;


trait humidity_privateTrait {
  private $humidity;

}
