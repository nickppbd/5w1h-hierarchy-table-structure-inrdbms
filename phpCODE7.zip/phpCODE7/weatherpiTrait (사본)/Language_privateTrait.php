<?php

namespace weatherpi\weatherpiTrait;


trait Language_privateTrait {
  private $language;

}
