<?php

namespace weatherpi\weatherpiTrait;


trait Pdo_protected_initialValue_arrayTrait {
  protected $pdo = array();

}
