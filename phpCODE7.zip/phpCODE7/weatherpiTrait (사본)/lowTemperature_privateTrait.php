<?php

namespace weatherpi\weatherpiTrait;


trait lowTemperature_privateTrait {
  private $lowTemperature;

}
