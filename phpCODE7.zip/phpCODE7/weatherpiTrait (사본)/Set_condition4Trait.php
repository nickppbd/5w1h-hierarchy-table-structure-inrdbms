<?php

namespace weatherpi\weatherpiTrait;


trait Set_condition4Trait {
  public function set_condition4(string $condition4)
  {
    $this->condition = $condition4;
  }

}
