<?php

namespace weatherpi\weatherpiTrait;


trait Set_topNodeTableId4Trait {
  protected function set_topNodeTableId4(string $topNodeTableId4)
  {
    $this->topNodeTableId = $topNodeTableId4;
  }

}
