<?php

namespace weatherpi\weatherpiTrait;


trait Host_privateTrait {
  private $host;

}
