<?php

namespace weatherpi\weatherpiTrait;


trait timeToStart_privateTrait {
  private $timeToStart;

}
