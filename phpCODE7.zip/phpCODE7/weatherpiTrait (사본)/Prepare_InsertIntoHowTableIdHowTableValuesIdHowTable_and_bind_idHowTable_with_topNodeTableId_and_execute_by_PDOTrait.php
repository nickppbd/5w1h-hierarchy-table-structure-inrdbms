<?php

namespace weatherpi\weatherpiTrait;


trait Prepare_InsertIntoHowTableIdHowTableValuesIdHowTable_and_bind_idHowTable_with_topNodeTableId_and_execute_by_PDOTrait {
  private function prepare_InsertIntoHowTableIdHowTableValuesIdHowTable_and_bind_idHowTable_with_topNodeTableId_and_execute_by_PDO()
  {
    $stmt= $this->pdo->prepare($this->get_sql_InsertIntoHowTableIdHowTableValuesIdHowTable());
    parent::create_data();
    $stmt->bindValue(':idHowTable', $this->topNodeTableId);
    $stmt->execute();
  }

}
