<?php

namespace weatherpi\weatherpiTrait;

use \weatherpi\weatherpiInterface\PDO0001;

trait Set_pdo0001Trait {
  public function set_pdo0001(PDO0001 $pdo0001)
  {
    $this->pdo = $pdo0001;
  }

}
