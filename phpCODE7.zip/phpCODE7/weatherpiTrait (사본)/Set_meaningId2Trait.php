<?php

namespace weatherpi\weatherpiTrait;


trait Set_meaningId2Trait {
  public function set_meaningId2(int $meaningId2)
  {
    $this->meaningId = $meaningId2;
  }

}
