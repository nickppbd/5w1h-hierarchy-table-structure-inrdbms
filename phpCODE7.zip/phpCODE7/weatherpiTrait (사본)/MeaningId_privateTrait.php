<?php

namespace weatherpi\weatherpiTrait;


trait MeaningId_privateTrait {
  private $meaningId;

}
