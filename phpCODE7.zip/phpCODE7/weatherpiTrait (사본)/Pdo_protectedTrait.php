<?php

namespace weatherpi\weatherpiTrait;


trait Pdo_protectedTrait {
  protected $pdo;

}
