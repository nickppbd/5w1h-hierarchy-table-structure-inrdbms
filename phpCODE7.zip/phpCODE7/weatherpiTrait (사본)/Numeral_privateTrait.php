<?php

namespace weatherpi\weatherpiTrait;


trait Numeral_privateTrait {
  private $numeral;

}
