<?php

namespace weatherpi\weatherpiTrait;


trait Set_numeral0Trait {
  public function set_numeral0(string $numeral0)
  {
    $this->numeral = $numeral0;
  }

}
