<?php

namespace weatherpi\weatherpiTrait;


trait Set_humidity2Trait {
  public function set_humidity2(int $humidity2)
  {
    $this->humidity = $humidity2;
  }

}
