<?php

namespace weatherpi\weatherpiTrait;


trait NameLanguage_privateTrait {
  private $nameLanguage;

}
