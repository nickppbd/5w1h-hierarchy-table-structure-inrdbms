<?php

namespace weatherpi\weatherpiTrait;


trait SetPassword_undefined_stringTrait {
  public function setPassword_undefined_string_weatherpi(string $password)
  {
    $this->password = $password;
  }

}
