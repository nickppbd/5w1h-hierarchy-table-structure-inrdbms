<?php

namespace weatherpi\weatherpiTrait;


trait time_protectedTrait {
  protected $time;

}
