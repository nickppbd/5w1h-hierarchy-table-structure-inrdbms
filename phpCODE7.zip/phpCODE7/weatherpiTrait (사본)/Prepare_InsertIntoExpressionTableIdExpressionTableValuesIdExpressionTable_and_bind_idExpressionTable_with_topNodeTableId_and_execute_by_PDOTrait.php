<?php

namespace weatherpi\weatherpiTrait;


trait Prepare_InsertIntoExpressionTableIdExpressionTableValuesIdExpressionTable_and_bind_idExpressionTable_with_topNodeTableId_and_execute_by_PDOTrait {
  protected function prepare_InsertIntoExpressionTableIdExpressionTableValuesIdExpressionTable_and_bind_idExpressionTable_with_topNodeTableId_and_execute_by_PDO()
  {
    $stmt= $this->pdo->prepare($this->get_sql_InsertIntoExpressionTableIdExpressionTableValuesIdExpressionTable());
    parent::create_data();
    $stmt->bindValue(':idExpressionTable', $this->topNodeTableId);
    $stmt->execute();
  }

}
