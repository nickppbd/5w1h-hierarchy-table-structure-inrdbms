<?php

namespace weatherpi\weatherpiTrait;


trait SetHost_undefined_stringTrait {
  public function setHost_undefined_string_weatherpi(string $host)
  {
    $this->host = $host;
  }

}
