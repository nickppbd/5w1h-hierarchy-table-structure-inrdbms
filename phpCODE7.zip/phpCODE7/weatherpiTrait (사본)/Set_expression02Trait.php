<?php

namespace weatherpi\weatherpiTrait;


trait Set_expression02Trait {
}
