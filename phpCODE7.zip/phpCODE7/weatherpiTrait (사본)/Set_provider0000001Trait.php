<?php

namespace weatherpi\weatherpiTrait;


trait Set_provider0000001Trait {
  public function set_provider0000001(\weatherpi\weatherpiInterface\Expression0001Interface $provider0000001)
  {
    $this->provider = $provider4;
  }

}
