<?php

namespace weatherpi\weatherpiTrait;


trait humidity_publicTrait {
  public $humidity;

}
