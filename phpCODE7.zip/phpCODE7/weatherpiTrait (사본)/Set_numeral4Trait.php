<?php

namespace weatherpi\weatherpiTrait;


trait Set_numeral4Trait {
  public function set_numeral4(string $numeral4)
  {
    $this->numeral = $numeral4;
  }

}
