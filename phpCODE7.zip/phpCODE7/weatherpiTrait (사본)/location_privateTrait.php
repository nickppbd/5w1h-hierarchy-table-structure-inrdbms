<?php

namespace weatherpi\weatherpiTrait;


trait location_privateTrait {
  private $location;

}
