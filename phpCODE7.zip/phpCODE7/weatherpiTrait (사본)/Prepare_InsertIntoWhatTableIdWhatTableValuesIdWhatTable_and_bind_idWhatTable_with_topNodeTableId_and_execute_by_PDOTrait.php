<?php

namespace weatherpi\weatherpiTrait;


trait Prepare_InsertIntoWhatTableIdWhatTableValuesIdWhatTable_and_bind_idWhatTable_with_topNodeTableId_and_execute_by_PDOTrait {
  public function prepare_InsertIntoWhatTableIdWhatTableValuesIdWhatTable_and_bind_idWhatTable_with_topNodeTableId_and_execute_by_PDO()
  {
    $stmt= $this->pdo->prepare($this->get_sql());
    parent::create_data();
    $stmt->bindValue(':id', $this->topNodeTableId);
    $stmt->execute();
  }

}
