<?php

namespace weatherpi\weatherpiTrait;


trait description_privateTrait {
  private $description;

}
