<?php

namespace weatherpi\weatherpiTrait;


trait Username_privateTrait {
  private $username;

}
