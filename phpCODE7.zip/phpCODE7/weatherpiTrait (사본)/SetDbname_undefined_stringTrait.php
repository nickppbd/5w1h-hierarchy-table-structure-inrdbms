<?php

namespace weatherpi\weatherpiTrait;


trait SetDbname_undefined_stringTrait {
  public function setDbname_undefined_string_weatherpi(string $dbname)
  {
    $this->dbname = $dbname;
  }

}
