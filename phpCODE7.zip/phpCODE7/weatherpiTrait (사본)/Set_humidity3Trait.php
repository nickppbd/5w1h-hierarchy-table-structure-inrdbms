<?php

namespace weatherpi\weatherpiTrait;


trait Set_humidity3Trait {
  public function set_humidity3(float $humidity3)
  {
    $this->humidity = $humidity3;
  }

}
