<?php

namespace weatherpi\weatherpiTrait;


trait Prepare_sql_and_parent_create_data_and_bindValue_and_execute_by_PDOTrait {
  private function prepare_sql_and_parent_create_data_and_bindValue_and_execute_by_PDO()
  {
    $stmt= $this->pdo->prepare($this->get_sql());
    parent::create_data();
    $stmt->bindValue(':id', $this->topNodeTableId);
    $stmt->execute();
  }

}
