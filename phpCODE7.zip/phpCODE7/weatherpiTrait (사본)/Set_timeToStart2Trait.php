<?php

namespace weatherpi\weatherpiTrait;


trait Set_timeToStart2Trait {
  public function set_timeToStart2(int $timeToStart2)
  {
    $this->timeToStart = $timeToStart2;
  }

}
