<?php

namespace weatherpi\weatherpiTrait;


trait temperature_privateTrait {
  private $temperature;

}
