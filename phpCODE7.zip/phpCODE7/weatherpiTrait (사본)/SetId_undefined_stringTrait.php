<?php

namespace weatherpi\weatherpiTrait;


trait SetId_undefined_stringTrait {
  public function setId_undefined_string_weatherpi(string $id)
  {
    $this->id = $id;
  }

}
