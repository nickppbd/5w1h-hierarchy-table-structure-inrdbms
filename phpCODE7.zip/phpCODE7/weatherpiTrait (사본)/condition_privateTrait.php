<?php

namespace weatherpi\weatherpiTrait;


trait condition_privateTrait {
  private $condition;

}
