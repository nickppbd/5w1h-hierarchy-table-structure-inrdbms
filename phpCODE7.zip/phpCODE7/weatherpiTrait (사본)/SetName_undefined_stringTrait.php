<?php

namespace weatherpi\weatherpiTrait;


trait SetName_undefined_stringTrait {
  public function setName_undefined_string_weatherpi(string $name)
  {
    $this->name = $name;
  }

}
