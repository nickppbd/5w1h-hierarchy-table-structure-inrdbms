<?php

namespace weatherpi\weatherpiTrait;


trait Set_language01Trait {
  public function set_language01(\weatherpi\language\Language01 $language01)
  {
    $this->language = $language01;
  }

}
