<?php

namespace weatherpi\weatherpiTrait;


trait Set_name0000001Trait {
  public function set_name0000001(\weatherpi\weatherpiInterface\Expression0001Interface $name0000001)
  {
    $this->name = $name0000001;
  }

}
