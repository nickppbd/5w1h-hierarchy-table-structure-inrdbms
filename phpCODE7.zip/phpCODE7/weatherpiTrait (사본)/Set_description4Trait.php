<?php

namespace weatherpi\weatherpiTrait;


trait Set_description4Trait {
  public function set_description4(string $description4)
  {
    $this->description = $description4;
  }

}
