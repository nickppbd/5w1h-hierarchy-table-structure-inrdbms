<?php

namespace weatherpi\weatherpiTrait;


trait Set_provider4Trait {
  public function set_provider4(string $provider4)
  {
    $this->provider = $provider4;
  }

}
