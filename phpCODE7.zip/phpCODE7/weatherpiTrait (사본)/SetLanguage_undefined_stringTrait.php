<?php

namespace weatherpi\weatherpiTrait;


trait SetLanguage_undefined_stringTrait {
  public function setLanguage_undefined_string_weatherpi(string $language)
  {
    $this->language = $language;
  }

}
