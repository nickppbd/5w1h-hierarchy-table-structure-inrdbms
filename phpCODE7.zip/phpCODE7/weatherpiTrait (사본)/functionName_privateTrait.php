<?php

namespace weatherpi\weatherpiTrait;


trait functionName_privateTrait {
  private $functionName;

}
