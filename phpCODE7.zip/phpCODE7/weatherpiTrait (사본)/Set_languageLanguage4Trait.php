<?php

namespace weatherpi\weatherpiTrait;


trait Set_languageLanguage4Trait {
  public function set_languageLanguage4(string $languageLanguage4)
  {
    $this->languageLanguage = $languageLanguage4;
  }

}
