<?php

namespace weatherpi\weatherpiTrait;


trait Set_functionName4Trait {
  public function set_functionName4(string $functionName4)
  {
    $this->functionName = $functionName4;
  }

}
