<?php

namespace weatherpi\weatherpiTrait;


trait provider_protectedTrait {
  protected $provider;

}
