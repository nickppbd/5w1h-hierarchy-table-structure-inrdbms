<?php

namespace weatherpi\weatherpiTrait;


trait MeaningId_protectedTrait {
  protected $meaningId;

}
