<?php

namespace weatherpi\weatherpiTrait;


trait Set_result4Trait {
  public function Set_result4(string $result4)
  {
    $this->result = $result4;
  }

}
