<?php

namespace weatherpi\weatherpiTrait;


trait provider_privateTrait {
  private $provider;

}
