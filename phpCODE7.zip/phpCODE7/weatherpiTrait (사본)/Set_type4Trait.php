<?php

namespace weatherpi\weatherpiTrait;


trait Set_type4Trait {
  public function set_type4(string $type4)
  {
    $this->type = $type4;
  }

}
