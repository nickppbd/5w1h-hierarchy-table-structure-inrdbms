<?php

namespace weatherpi\weatherpiTrait;


trait Set_time4Trait {
  public function set_time4(string $time4)
  {
    $this->time = $time4;
  }

}
