<?php

namespace weatherpi\weatherpiTrait;


trait timeToStart_publicTrait {
  public $timeToStart;

}
