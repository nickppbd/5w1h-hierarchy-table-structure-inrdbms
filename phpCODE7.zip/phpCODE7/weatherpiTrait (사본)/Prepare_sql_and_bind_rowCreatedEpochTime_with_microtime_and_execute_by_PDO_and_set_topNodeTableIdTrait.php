<?php

namespace weatherpi\weatherpiTrait;


trait Prepare_sql_and_bind_rowCreatedEpochTime_with_microtime_and_execute_by_PDO_and_set_topNodeTableIdTrait {
  private function prepare_sql_and_bind_rowCreatedEpochTime_with_microtime_and_execute_by_PDO_and_set_topNodeTableId()
  {
    $stmt= $this->pdo->prepare($this->get_sql());
    $stmt->bindValue(':rowCreatedEpochTime',microtime(true));
    $stmt->execute();
    $this->set_topNodeTableId4($this->pdo->lastInsertId());
  }

}
