<?php

namespace weatherpi\weatherpiTrait;


trait Set_lowTemperature2Trait {
  public function set_lowTemperature2(int $lowTemperature2)
  {
    $this->lowTemperature = $lowTemperature2;
  }

}
