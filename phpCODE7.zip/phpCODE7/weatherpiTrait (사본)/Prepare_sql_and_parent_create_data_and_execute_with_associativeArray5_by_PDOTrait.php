<?php

namespace weatherpi\weatherpiTrait;


trait Prepare_sql_and_parent_create_data_and_execute_with_associativeArray5_by_PDOTrait {
  private function prepare_sql_and_parent_create_data_and_execute_with_associativeArray5_by_PDO(array $associativeArray5)
  {
    $stmt= $this->pdo->prepare($this->get_sql());
    parent::create_data();
    $associativeArray5['id'] = $this->topNodeTableId;
    $stmt->execute($associativeArray5);
  }

}
