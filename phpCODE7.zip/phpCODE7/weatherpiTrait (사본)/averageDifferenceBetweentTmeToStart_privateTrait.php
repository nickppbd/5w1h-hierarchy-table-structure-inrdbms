<?php

namespace weatherpi\weatherpiTrait;


trait averageDifferenceBetweentTmeToStart_privateTrait {
  private $averageDifferenceBetweentTmeToStart;

}
