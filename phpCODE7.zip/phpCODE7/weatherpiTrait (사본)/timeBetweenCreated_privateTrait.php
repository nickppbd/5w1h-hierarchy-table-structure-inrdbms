<?php

namespace weatherpi\weatherpiTrait;


trait timeBetweenCreated_privateTrait {
  private $timeBetweenCreated;

}
