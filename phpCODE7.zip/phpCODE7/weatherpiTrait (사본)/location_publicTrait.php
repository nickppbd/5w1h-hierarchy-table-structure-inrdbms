<?php

namespace weatherpi\weatherpiTrait;


trait location_publicTrait {
  public $location;

}
