<?php

namespace weatherpi\weatherpiTrait;


trait Set_location4Trait {
  public function set_location4(string $location4)
  {
    $this->location = $location4;
  }

}
