<?php

namespace weatherpi\weatherpiTrait;


trait Set_nameLanguage4Trait {
  public function set_nameLanguage4(string $nameLanguage4)
  {
    $this->nameLanguage = $nameLanguage4;
  }

}
