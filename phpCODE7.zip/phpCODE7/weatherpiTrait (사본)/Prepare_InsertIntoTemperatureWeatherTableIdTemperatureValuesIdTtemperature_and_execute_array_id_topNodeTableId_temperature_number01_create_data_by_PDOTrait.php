<?php

namespace weatherpi\weatherpiTrait;

use \weatherpi\number\Number01;

trait Prepare_InsertIntoTemperatureWeatherTableIdTemperatureValuesIdTtemperature_and_execute_array_id_topNodeTableId_temperature_number01_create_data_by_PDOTrait {
  private function prepare_InsertIntoTemperatureWeatherTableIdTemperatureValuesIdTtemperature_and_execute_array_id_topNodeTableId_temperature_number01_create_data_by_PDO()
  {
    $number = new Number01();
    $number->set_numeral0($this->temperature);
    $number->set_pdo0001($this->pdo);
    $stmt= $this->pdo->prepare('Insert Into TemperatureWeatherTable (id, temperature) Values (:id, :temperature);');
    $stmt->execute(['id' => $this->topNodeTableId, 'temperature' => $number->create_data()]);
  }

}
