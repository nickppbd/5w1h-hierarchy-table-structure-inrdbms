<?php

namespace weatherpi\weatherpiTrait;


trait type_protectedTrait {
  protected $type;

}
