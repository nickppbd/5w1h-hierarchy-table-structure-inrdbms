<?php

namespace weatherpi\weatherpiTrait;


trait Set_language4Trait {
  public function set_language4(string $language4)
  {
    $this->language = $language4;
  }

}
