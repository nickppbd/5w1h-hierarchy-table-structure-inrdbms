<?php

namespace weatherpi\weatherpiTrait;

use \weatherpi\expressionMeaningLanguage\ExpressionMeaningLanguage01;

trait Prepare_InsertIntoDescriptionWeatherTableIdDescriptionValuesIdDescription_and_execute_array_id_topNodeTableId_description_expressionMeaningLanguage01_get_meaningId2_by_PDOTrait {
  private function prepare_InsertIntoDescriptionWeatherTableIdDescriptionValuesIdDescription_and_execute_array_id_topNodeTableId_description_expressionMeaningLanguage01_get_meaningId2_by_PDO()
  {
    $expressionMeaningLanguage = new ExpressionMeaningLanguage01();
    $expressionMeaningLanguage->set_expression4($this->description); 
    $expressionMeaningLanguage->set_language4('english'); 
    $expressionMeaningLanguage->set_pdo0001($this->pdo);
    $expressionMeaningLanguage->create_data();
    $stmt= $this->pdo->prepare('Insert Into DescriptionWeatherTable (id, description) Values (:id, :description);');
    $stmt->execute(['id' => $this->topNodeTableId, 'description' => $expressionMeaningLanguage->get_meaningId2()]);
  }

}
