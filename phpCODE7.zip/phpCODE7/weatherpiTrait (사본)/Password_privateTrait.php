<?php

namespace weatherpi\weatherpiTrait;


trait Password_privateTrait {
  private $password;

}
