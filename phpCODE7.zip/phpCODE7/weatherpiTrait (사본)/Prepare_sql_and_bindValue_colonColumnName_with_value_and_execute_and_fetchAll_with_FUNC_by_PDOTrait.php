<?php

namespace weatherpi\weatherpiTrait;


trait Prepare_sql_and_bindValue_colonColumnName_with_value_and_execute_and_fetchAll_with_FUNC_by_PDOTrait {
  private function prepare_sql_and_bindValue_colonColumnName_with_value_and_execute_and_fetchAll_with_FUNC_by_PDO()
  {
    $stmt= $this->pdo->prepare($this->get_selectSql4());
    $stmt->bindValue($this->get_colonColumnName4(), $this->get_bindedValue0());
    $stmt->execute();
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, $this->get_fetchArgument0());
    return $result;
  }

}
