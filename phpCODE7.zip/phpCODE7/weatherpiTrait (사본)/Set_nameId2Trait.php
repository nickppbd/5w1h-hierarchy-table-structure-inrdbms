<?php

namespace weatherpi\weatherpiTrait;


trait Set_nameId2Trait {
  public function set_nameId2(int $nameId2)
  {
    $this->nameId = $nameId2;
  }

}
