<?php

namespace weatherpi\weatherpiTrait;


trait Name_privateTrait {
  private $name;

}
