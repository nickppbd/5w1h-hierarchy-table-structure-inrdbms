<?php

namespace weatherpi\weatherpiTrait;


trait Set_endedTime3Trait {
  public function set_endedTime3(float $endedTime3)
  {
    $this->endedTime = $endedTime3;
  }

}
trait Set_epochTime3Trait {
  public function set_epochTime3(float $epochTime3)
  {
    $this->epochTime = $epochTime3;
  }

}
