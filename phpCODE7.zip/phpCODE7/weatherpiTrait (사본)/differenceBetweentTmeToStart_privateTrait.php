<?php

namespace weatherpi\weatherpiTrait;


trait differenceBetweentTmeToStart_privateTrait {
  private $timeBetweenCreated;

}
