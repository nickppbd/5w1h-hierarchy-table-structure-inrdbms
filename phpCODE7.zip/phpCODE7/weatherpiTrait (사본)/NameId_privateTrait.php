<?php

namespace weatherpi\weatherpiTrait;


trait NameId_privateTrait {
  private $nameId;

}
