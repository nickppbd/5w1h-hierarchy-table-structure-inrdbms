<?php

namespace weatherpi\weatherpiTrait;


trait Set_temperature3Trait {
  public function set_temperature3(float $temperature3)
  {
    $this->temperature = $temperature3;
  }

}
