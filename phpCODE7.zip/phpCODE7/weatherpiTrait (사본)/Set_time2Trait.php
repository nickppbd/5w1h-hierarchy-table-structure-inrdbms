<?php

namespace weatherpi\weatherpiTrait;


trait Set_time2Trait {
  public function set_time2(int $time2)
  {
    $this->time = $time2;
  }

}
