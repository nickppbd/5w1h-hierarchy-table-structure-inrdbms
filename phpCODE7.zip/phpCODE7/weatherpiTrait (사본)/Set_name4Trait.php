<?php

namespace weatherpi\weatherpiTrait;


trait Set_name4Trait {
  public function set_name4(string $name4)
  {
    $this->name = $name4;
  }

}
