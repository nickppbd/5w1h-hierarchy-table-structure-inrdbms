<?php

namespace weatherpi\weatherpiTrait;


trait Prepare_and_bind_and_execute_by_PDO0001Trait {
  public function prepare_InsertIntoTopNodeTableRowCreatedEpochTimeValuesRowCreatedEpochTime_and_bind_rowCreatedEpochTime_with_microtime_and_execute_by_PDO0001(\weatherpi\weatherpiInterface\PDO0001 $pDO0001)
  {
    $stmt= $pDO0001->prepare($this->return_sql_InsertIntoTopNodeTableRowCreatedEpochTimeValuesRowCreatedEpochTime_weatherpi());
    $stmt->bindValue(':rowCreatedEpochTime',microtime(true));
    $stmt->execute();
  }

}
