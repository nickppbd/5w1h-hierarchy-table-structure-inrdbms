<?php

namespace weatherpi\weatherpiTrait;


trait topNodeTableId_protectedTrait {
  protected $topNodeTableId;

}
