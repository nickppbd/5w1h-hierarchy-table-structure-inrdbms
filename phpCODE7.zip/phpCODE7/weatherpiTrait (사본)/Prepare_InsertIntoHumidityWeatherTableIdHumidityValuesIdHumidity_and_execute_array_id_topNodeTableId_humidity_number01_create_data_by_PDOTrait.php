<?php

namespace weatherpi\weatherpiTrait;

use \weatherpi\number\Number01;

trait Prepare_InsertIntoHumidityWeatherTableIdHumidityValuesIdHumidity_and_execute_array_id_topNodeTableId_humidity_number01_create_data_by_PDOTrait {
  private function prepare_InsertIntoHumidityWeatherTableIdHumidityValuesIdHumidity_and_execute_array_id_topNodeTableId_humidity_number01_create_data_by_PDO()
  {
    $number = new Number01();
    $number->set_numeral0($this->humidity);
    $number->set_pdo0001($this->pdo);
    $stmt= $this->pdo->prepare('Insert Into HumidityWeatherTable (id, humidity) Values (:id, :humidity);');
    $stmt->execute(['id' => $this->topNodeTableId, 'humidity' => $number->create_data()]);
  }

}
