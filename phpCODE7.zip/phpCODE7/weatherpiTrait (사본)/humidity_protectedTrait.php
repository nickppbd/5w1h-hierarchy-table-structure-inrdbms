<?php

namespace weatherpi\weatherpiTrait;


trait humidity_protectedTrait {
  protected $humidity;

}
