<?php

namespace weatherpi\weatherpiTrait;


trait Set_language0000001Trait {
  public function set_language0000001(\weatherpi\weatherpiInterface\Language0001Interface $language0000001)
  {
    $this->language = $language0000001;
  }

}
