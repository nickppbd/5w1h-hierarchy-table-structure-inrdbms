<?php

namespace weatherpi\weatherpiTrait;


trait Set_expression4Trait {
  public function set_expression4(string $expression4)
  {
    $this->expression = $expression4;
  }

}
