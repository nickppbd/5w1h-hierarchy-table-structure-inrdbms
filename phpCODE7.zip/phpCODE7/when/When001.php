<?php

namespace weatherpi\when;

use \weatherpi\topNode\TopNode01;

abstract class When001 extends TopNode01 {
  public function create_data()
  {
    $stmt= $this->pdo->prepare('Insert Into WhenTable (id) Values (:id);');
    parent::create_data();
    $stmt->bindValue(':id', $this->topNodeTableId);
    $stmt->execute();
  }

}
