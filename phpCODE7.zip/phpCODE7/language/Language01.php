<?php

namespace weatherpi\language;

use \weatherpi\what\What001;
use \weatherpi\weatherpiTrait\Name_privateTrait;
use \weatherpi\weatherpiTrait\Set_name4Trait;
use \weatherpi\expression\Expression03;
use \weatherpi\expressionMeaning\ExpressionMeaning01;
use \weatherpi\weatherpiTrait\NameId_privateTrait;
use \weatherpi\weatherpiTrait\Set_nameId2Trait;
use \weatherpi\weatherpiTrait\Get_meaningId2Trait;
use \weatherpi\weatherpiTrait\ExpressionMeaningId_privateTrait;
use \weatherpi\weatherpiTrait\Get_expressionMeaningId2Trait;

class Language01 extends What001 {
  use Name_privateTrait;
  use Set_name4Trait;
  use NameId_privateTrait;
  use Set_nameId2Trait;
  use Get_meaningId2Trait;
  use ExpressionMeaningId_privateTrait;
  use Get_expressionMeaningId2Trait;
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    /*$sql = 'Select LT1.id As id From LanguageTable As LT1
    Inner Join ExpressionMeaningTable As EMT1
    On LT1.name = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Where WSET1.expression = :name Limit 1 For Update;';*/
    
    $sql = 'Select LT1.id As id, EMT1.id As expressionMeaningId From LanguageTable As LT1
        Inner Join ExpressionMeaningTable As EMT1
        On LT1.name = EMT1.meaning
        Inner Join WritingSystemExpressionTable As WSET1
        On EMT1.expression = WSET1.id
        Where WSET1.expression = :name Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['name' => $this->name]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id, $expressionMeaningId){$this->expressionMeaningId = (int)$expressionMeaningId; return $id;});
    return $result;
  }

  private function create_newData()
  {
    $expressionMeaning = new ExpressionMeaning01();
    $expressionMeaning->set_expression4($this->name);
    $expressionMeaning->set_pdo0001($this->pdo);
    $this->expressionMeaningId = (int)$expressionMeaning->create_data();
    $sql = 'Insert Into LanguageTable (id, name) Values (:id, :name);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'name' => $expressionMeaning->get_meaningId2()]);
    return $this->topNodeTableId;
  }

  public function create_data_with_nameId()
  {
    if(!empty($id = $this->does_exist_with_nameId())) {
        return $id[0];
    }
    /*
    $expressionMeaning = new ExpressionMeaning01();
    $expressionMeaning->set_expression4($this->name);
    $expressionMeaning->set_meaningId2($this->nameId);
    $expressionMeaning->set_pdo0001($this->pdo);
    $expressionMeaning->create_data_with_meaningId();
    $id = $this->read_id_where_name_is_nameId();
    return $id[0];
    */
    
    $sql = 'Insert Into LanguageTable (id, name) Values (:id, :name);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'name' => $this->nameId]);
    return $this->topNodeTableId;
    
  }

  private function does_exist_with_nameId()
  {
    /*
    $sql = 'Select LT1.id As id From LanguageTable As LT1
    Inner Join ExpressionMeaningTable As EMT1
    On LT1.name = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Where WSET1.expression = :expression And EMT1.meaning = :meaning Limit 1 For Update;';
    */
    $sql = 'Select LT1.id As id From LanguageTable As LT1
    Inner Join ExpressionMeaningTable As EMT1
    On LT1.name = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Where EMT1.meaning = :meaning Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['meaning' => $this->nameId]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){ return $id;});
    return $result;
  }

  private function read_id_where_name_is_nameId()
  {
    $sql = 'Select id From LanguageTable Where name = :name Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['name' => $this->nameId]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){ return $id;});
    return $result;
  }

  private function create_data_with_meaningId2(int $meaningId2)
  {
    $expression = new Expression03();
    $expression->set_expression4($this->expression);
    $expression->set_pdo0001($this->pdo);
    $sql = 'Insert Into ExpressionMeaningTable (id, expression, meaning) Values (:id, :expression, :meaning);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'expression' => (int)$expression->create_data(), 'meaning' => $meaningId2]);
    return $this->topNodeTableId;
  }

}
