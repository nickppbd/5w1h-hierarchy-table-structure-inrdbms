<?php

namespace weatherpi\number;

use \weatherpi\weatherpiTrait\Numeral_privateTrait;
use \weatherpi\expressionMeaning\ExpressionMeaning01;
use \weatherpi\what\What001;
use \weatherpi\weatherpiTrait\Set_numeral0Trait;

class Number01 extends What001 {
  use Numeral_privateTrait;
  use Set_numeral0Trait;
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $sql = 'Select NT1.id As id From NumberTable As NT1
    Inner Join ExpressionMeaningTable As EMT1
    On NT1.numeral = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Where WSET1.expression = :numeral Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['numeral' => $this->numeral]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){return $id;});
    return $result;
  }

  private function create_newData()
  {
    $expressionMeaning = new ExpressionMeaning01();
    $expressionMeaning->set_expression4($this->numeral);
    $expressionMeaning->set_pdo0001($this->pdo);
    $expressionMeaning->create_data();
    $sql = 'Insert Into NumberTable (id, numeral) Values (:id, :numeral);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'numeral' => $expressionMeaning->get_meaningId2()]);
    return $this->topNodeTableId;
  }

}
