<?php

namespace weatherpi\weatherpiPDO;


final class PDO02 extends \PDO {
  public function __construct(string $dsn, string $username = null, string $passwd = null, array $options = null)
  {
    parent::__construct($dsn, $username, $passwd, $options);
    if (!($this->getAttribute(\PDO::ATTR_DRIVER_NAME) == 'sqlite')) {
        throw new \Exception('my application only works with sqlite');
    }
  }

}
