<?php

namespace weatherpi\weatherpiPDO;

use \weatherpi\weatherpiInterface\PDO0001;

final class PDO01 extends \PDO implements PDO0001 {
  public function __construct(string $dsn, string $username = null, string $passwd = null, array $options = null)
  {
    parent::__construct($dsn, $username, $passwd, $options);
    if (!($this->getAttribute(\PDO::ATTR_DRIVER_NAME) == 'mysql')) {
        throw new \Exception('my application only works with mysql');
    }
  }

}
