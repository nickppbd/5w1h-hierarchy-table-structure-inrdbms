<?php

namespace weatherpi\who;

use \weatherpi\topNode\TopNode01;
use \weatherpi\weatherpiTrait\Prepare_sql_and_parent_create_data_and_bindValue_and_execute_by_PDOTrait;
use \weatherpi\weatherpiTrait\Get_sql_InsertIntoWhoTableIdValuesIdTrait;

abstract class Who001 extends TopNode01 {
use Prepare_sql_and_parent_create_data_and_bindValue_and_execute_by_PDOTrait {
	prepare_sql_and_parent_create_data_and_bindValue_and_execute_by_PDO as public create_data;
}
use Get_sql_InsertIntoWhoTableIdValuesIdTrait {
	get_sql_InsertIntoWhoTableIdValuesId as get_sql;
}
}
