<?php

namespace weatherpi\topNode;

use \weatherpi\weatherpiTrait\Pdo_protectedTrait;

class TopNode02 {
  use Pdo_protectedTrait;
}
