<?php

namespace weatherpi\meaning;

use \weatherpi\what\What001;

class Meaning01 extends What001 {
  public function create_data()
  {
    $sql = 'Insert Into MeaningTable (id) Values (:id);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId]);
    return $this->topNodeTableId;
  }

}
