<?php

namespace weatherpi\epochTime;

use \weatherpi\when\When001;
use \weatherpi\weatherpiTrait\EpochTime_privateTrait;
use \weatherpi\weatherpiTrait\Set_epochTime2Trait;
use \weatherpi\number\Number01;

class EpochTime01 extends When001 {
  use EpochTime_privateTrait;
  use Set_epochTime2Trait;
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $sql = 'Select * From EpochTimeTable As ETT1
    Inner Join NumberTable As NT1
    On ETT1.epochTime = NT1.id
    Inner Join ExpressionMeaningTable As EMT1
    On NT1.numeral = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Where WSET1.expression = :epochTime Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['epochTime' => $this->epochTime]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){return $id;});
    return $result;
  }

  private function create_newData()
  {
    $number = new Number01();
    $number->set_numeral0($this->epochTime);
    $number->set_pdo0001($this->pdo);
    $sql = 'Insert Into EpochTimeTable (id, epochTime) Values (:id, :epochTime);';
    $stmt= $this->pdo->prepare($sql);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'epochTime' => $number->create_data()]);
    return $this->topNodeTableId;
  }

}
