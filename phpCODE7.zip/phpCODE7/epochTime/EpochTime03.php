<?php

namespace weatherpi\epochTime;


class EpochTime03 {
}
