<?php

namespace weatherpi\database;

use \weatherpi\weatherpiInterface\DatabaseAbstractInterface;

abstract class Database implements DatabaseAbstractInterface {
}
