<?php

namespace weatherpi\database;

use \weatherpi\weatherpiInterface\Database_1Interface;
use \weatherpi\weatherpiTrait\Dbname_privateTrait;
use \weatherpi\weatherpiTrait\Host_privateTrait;
use \weatherpi\weatherpiTrait\Password_privateTrait;
use \weatherpi\weatherpiTrait\Username_privateTrait;
use \weatherpi\weatherpiTrait\GetConnection_PDOTrait;
use \weatherpi\weatherpiTrait\SetHost_undefined_stringTrait;
use \weatherpi\weatherpiTrait\SetDbname_undefined_stringTrait;
use \weatherpi\weatherpiTrait\GetUsername_stringTrait;
use \weatherpi\weatherpiTrait\SetUsername_undefined_stringTrait;
use \weatherpi\weatherpiTrait\SetPassword_undefined_stringTrait;

class Database_1 extends Database implements Database_1Interface {
  use Dbname_privateTrait;
  use Host_privateTrait;
  use Password_privateTrait;
  use Username_privateTrait;
  use GetConnection_PDOTrait;
  use SetHost_undefined_stringTrait;
  use SetDbname_undefined_stringTrait;
  use GetUsername_stringTrait;
  use SetUsername_undefined_stringTrait;
  use SetPassword_undefined_stringTrait;
}
