<?php

namespace weatherpi\schedule;

use \weatherpi\topNode\TopNode02;
use \weatherpi\weatherpiTrait\timeToStart_publicTrait;
use \weatherpi\weatherpiTrait\functionName_publicTrait;
use \weatherpi\weatherpiTrait\location_publicTrait;

class Schedule02 extends TopNode02 {
  use timeToStart_publicTrait;
  use functionName_publicTrait;
  use location_publicTrait;
}
