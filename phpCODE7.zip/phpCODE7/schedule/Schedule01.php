<?php

namespace weatherpi\schedule;

use \weatherpi\what\What001;
use \weatherpi\weatherpiTrait\endedTime_privateTrait;
use \weatherpi\weatherpiTrait\Set_endedTime3Trait;
use \weatherpi\weatherpiTrait\timeToStart_privateTrait;
use \weatherpi\weatherpiTrait\Set_timeToStart2Trait;
use \weatherpi\weatherpiTrait\location_privateTrait;
use \weatherpi\weatherpiTrait\Set_location4Trait;
use \weatherpi\epochTime\EpochTime01;
use \weatherpi\epochTime\EpochTime02;
use \weatherpi\weatherpiTrait\Result_privateTrait;
use \weatherpi\weatherpiTrait\Set_result4Trait;
use \weatherpi\expressionMeaningLanguage\ExpressionMeaningLanguage01;
use \weatherpi\weatherpiTrait\Set_functionName4Trait;
use \weatherpi\task\Task02;
use \weatherpi\weatherpiTrait\functionName_privateTrait;
use \weatherpi\weatherpiTrait\Get_functionName4Trait;
use \weatherpi\weatherpiTrait\Get_location4Trait;
use \weatherpi\weatherpiTrait\Get_timeToStart2Trait;
use \weatherpi\weatherpiTrait\differenceBetweentTmeToStart_privateTrait;
use \weatherpi\weatherpiTrait\Set_differenceBetweentTmeToStart2Trait;
use \weatherpi\weatherpiTrait\Get_differenceBetweentTmeToStart2Trait;
use \weatherpi\weatherpiTrait\Get_endedTime3Trait;
use \weatherpi\weatherpiTrait\averageDifferenceBetweentTmeToStart_privateTrait;
use \weatherpi\weatherpiTrait\Get_averageDifferenceBetweentTmeToStart3Trait;

class Schedule01 extends What001 {
  use endedTime_privateTrait;
  use Set_endedTime3Trait;
  use timeToStart_privateTrait;
  use Set_timeToStart2Trait;
  use location_privateTrait;
  use Set_location4Trait;
  use Result_privateTrait;
  use Set_result4Trait;
  use functionName_privateTrait;
  use Set_functionName4Trait;
  use Get_functionName4Trait;
  use Get_location4Trait;
  use Get_timeToStart2Trait;
  use differenceBetweentTmeToStart_privateTrait;
  use Set_differenceBetweentTmeToStart2Trait;
  use Get_differenceBetweentTmeToStart2Trait;
  use Get_endedTime3Trait;
  use averageDifferenceBetweentTmeToStart_privateTrait;
  use Get_averageDifferenceBetweentTmeToStart3Trait;
  public function does_exist()
  {
    $sql = 'Select ST1.id As id From ScheduleTable As ST1
    Inner Join EpochTimeTable As ETT1
    On ST1.timeToStart = ETT1.id
    Inner Join NumberTable As NT1
    On ETT1.epochTime = NT1.id
    Inner Join ExpressionMeaningTable As EMT1
    On NT1.numeral = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Inner Join LocationTaskTable As LTT1
    On ST1.eventOrTask = LTT1.id
    Inner Join LocationTable As LT1
    On LTT1.location = LT1.id
    Inner Join ExpressionMeaningTable As EMT2
    On LT1.name = EMT2.meaning
    Inner Join WritingSystemExpressionTable As WSET2
    On EMT2.expression = WSET2.id
    Inner Join Program01ClassFunctionTaskTable As P01CFTT1
    On LTT1.id = P01CFTT1.id
    Inner Join ExpressionMeaningTable As EMT3
    On ST1.result = EMT3.meaning
    Inner Join WritingSystemExpressionTable As WSET3
    On EMT3.expression = WSET3.id
    Inner Join EndedTimeScheduleTable As ETST1
    On ST1.id = ETST1.id
    Inner Join EpochTimeTable As ETT2
    On ETST1.endedTime = ETT2.id
    Inner Join NumberTable As NT2
    On ETT2.epochTime = NT2.id
    Inner Join ExpressionMeaningTable As EMT4
    On NT2.numeral = EMT4.meaning
    Inner Join WritingSystemExpressionTable As WSET4
    On EMT4.expression = WSET4.id
    Where WSET1.expression = :timeToStart And WSET2.expression = :location And 
    WSET3.expression = :result And WSET4.expression = :endedTime And 
    P01CFTT1.name = :functionName Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['timeToStart' => $this->timeToStart, 'location' => $this->location, 'result' => $this->result, 'endedTime' => $this->endedTime, 'functionName' => $this->functionName]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){return $id;});
    return $result;
  }

  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  private function create_newData()
  {
    $time = new EpochTime01();
    $time->set_epochTime2($this->timeToStart);
    $time->set_pdo0001($this->pdo);
    $task = new Task02();
    $task->set_location4($this->location);
    $task->set_functionName4($this->functionName);
    $task->set_pdo0001($this->pdo);
    $time2 = new EpochTime02();
    $time2->set_epochTime3($this->endedTime);
    $time2->set_pdo0001($this->pdo);
    $expressionMeaningLanguage = new ExpressionMeaningLanguage01();
    $expressionMeaningLanguage->set_expression4($this->result); 
    $expressionMeaningLanguage->set_language4('english'); 
    $expressionMeaningLanguage->set_pdo0001($this->pdo);
    $expressionMeaningLanguage->create_data();
    $sql = 'Insert Into ScheduleTable (id, timeToStart, eventOrTask, result) Values (:id, :timeToStart, :eventOrTask, :result);';
    $stmt= $this->pdo->prepare($sql);
    $sql2 = 'Insert Into EndedTimeScheduleTable (id, endedTime) Values (:id, :endedTime);';
    $stmt2= $this->pdo->prepare($sql2);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'timeToStart' => $time->create_data(), 'eventOrTask' => $task->create_data(), 'result' => $expressionMeaningLanguage->get_meaningId2()]);
    $stmt2->execute(['id' => $this->topNodeTableId, 'endedTime' => $time2->create_data()]);
    return $this->topNodeTableId;
  }

  public function set_to_do_data_from_db()
  {
    $sql = 'Select ST1.id As id, WSET1.expression As timeToStart, WSET2.expression As location, 
    P01CFTT1.name As functionName From ScheduleTable As ST1
    Inner Join EpochTimeTable As ETT1
    On ST1.timeToStart = ETT1.id
    Inner Join NumberTable As NT1
    On ETT1.epochTime = NT1.id
    Inner Join ExpressionMeaningTable As EMT1
    On NT1.numeral = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Inner Join LocationTaskTable As LTT1
    On ST1.eventOrTask = LTT1.id
    Inner Join LocationTable As LT1
    On LTT1.location = LT1.id
    Inner Join ExpressionMeaningTable As EMT2
    On LT1.name = EMT2.meaning
    Inner Join WritingSystemExpressionTable As WSET2
    On EMT2.expression = WSET2.id
    Inner Join Program01ClassFunctionTaskTable As P01CFTT1
    On LTT1.id = P01CFTT1.id
    Inner Join ExpressionMeaningTable As EMT3
    On ST1.result = EMT3.meaning
    Inner Join WritingSystemExpressionTable As WSET3
    On EMT3.expression = WSET3.id
    Where WSET3.expression = :result
    ORDER BY WSET1.expression ASC Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['result' => 'to do']);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id, $timeToStart, $location, $functionName){$this->topNodeTableId = $id; $this->timeToStart = (int)$timeToStart; $this->location = $location; $this->functionName = $functionName;});
    return $result;
  }

  public function update_endedTime_and_result_data()
  {
    $time = new EpochTime02();
    $time->set_epochTime3($this->endedTime);
    $time->set_pdo0001($this->pdo);
    $expressionMeaningLanguage = new ExpressionMeaningLanguage01();
    $expressionMeaningLanguage->set_expression4($this->result); 
    $expressionMeaningLanguage->set_language4('english'); 
    $expressionMeaningLanguage->set_pdo0001($this->pdo);
    $expressionMeaningLanguage->create_data();
    $stmt= $this->pdo->prepare('Update ScheduleTable SET result = :result WHERE id = :id;');
    $stmt2= $this->pdo->prepare('Update EndedTimeScheduleTable SET endedTime = :endedTime WHERE id = :id;');
    $stmt->execute(['id' => $this->topNodeTableId, 'result' => $expressionMeaningLanguage->get_meaningId2()]);
    $stmt2->execute(['id' => $this->topNodeTableId, 'endedTime' => $time->create_data()]);
  }

  public function read_averageDifferenceBetweentTmeToStart_or_more_differenceBetweentTmeToStart()
  {
    $sql = 'Select avg(timeToStartSubtractionLagTimeToStartOverOrderByTimeToStartAsc) As averageTimeToStartSubtractionLagTimeToStartOverOrderByTimeToStartAsc
    From (Select WSET1.expression - Lag(WSET1.expression) over (Order By WSET1.expression Asc) As timeToStartSubtractionLagTimeToStartOverOrderByTimeToStartAsc
    From ScheduleTable As ST1
    Inner Join EpochTimeTable As ETT1
    On ST1.timeToStart = ETT1.id
    Inner Join NumberTable As NT1
    On ETT1.epochTime = NT1.id
    Inner Join ExpressionMeaningTable As EMT1
    On NT1.numeral = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Inner Join LocationTaskTable As LTT1
    On ST1.eventOrTask = LTT1.id
    Inner Join LocationTable As LT1
    On LTT1.location = LT1.id
    Inner Join ExpressionMeaningTable As EMT2
    On LT1.name = EMT2.meaning
    Inner Join WritingSystemExpressionTable As WSET2
    On EMT2.expression = WSET2.id
    Inner Join Program01ClassFunctionTaskTable As P01CFTT1
    On LTT1.id = P01CFTT1.id
    Inner Join ExpressionMeaningTable As EMT3
    On ST1.result = EMT3.meaning
    Inner Join WritingSystemExpressionTable As WSET3
    On EMT3.expression = WSET3.id
    Where WSET2.expression = :location And WSET3.expression = :result And P01CFTT1.name = :functionName 
    ) t
    Where timeToStartSubtractionLagTimeToStartOverOrderByTimeToStartAsc >= :timeToStartSubtractionLagTimeToStartOverOrderByTimeToStartAsc For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['location' => $this->location, 'result' => $this->result, 'functionName' => $this->functionName, 'timeToStartSubtractionLagTimeToStartOverOrderByTimeToStartAsc' => $this->differenceBetweentTmeToStart]);
    $stmt->fetchAll(\PDO::FETCH_FUNC, function($averageTimeToStartSubtractionLagTimeToStartOverOrderByTimeToStartAsc){$this->averageDifferenceBetweentTmeToStart = $averageTimeToStartSubtractionLagTimeToStartOverOrderByTimeToStartAsc;});
  }

  public function read_maxEndedTime()
  {
    $sql = 'Select Max(WSET4.expression) As maxEndedTime
    From ScheduleTable As ST1
    Inner Join LocationTaskTable As LTT1
    On ST1.eventOrTask = LTT1.id
    Inner Join LocationTable As LT1
    On LTT1.location = LT1.id
    Inner Join ExpressionMeaningTable As EMT2
    On LT1.name = EMT2.meaning
    Inner Join WritingSystemExpressionTable As WSET2
    On EMT2.expression = WSET2.id
    Inner Join Program01ClassFunctionTaskTable As P01CFTT1
    On LTT1.id = P01CFTT1.id
    Inner Join ExpressionMeaningTable As EMT3
    On ST1.result = EMT3.meaning
    Inner Join WritingSystemExpressionTable As WSET3
    On EMT3.expression = WSET3.id
    Inner Join EndedTimeScheduleTable As ETST1
    On ST1.id = ETST1.id
    Inner Join EpochTimeTable As ETT1
    On ETST1.endedTime = ETT1.id
    Inner Join NumberTable As NT1
    On ETT1.epochTime = NT1.id
    Inner Join ExpressionMeaningTable As EMT4
    On NT1.numeral = EMT4.meaning
    Inner Join WritingSystemExpressionTable As WSET4
    On EMT4.expression = WSET4.id
    Where WSET2.expression = :location And WSET3.expression = :result And P01CFTT1.name = :functionName For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['location' => $this->location, 'result' => $this->result, 'functionName' => $this->functionName]);
    $stmt->fetchAll(\PDO::FETCH_FUNC, function($maxEndedTime){$this->endedTime = $maxEndedTime;});
  }

  public function read_lastDifferenceBetweentTmeToStart()
  {
    $sql = 'Select WSET1.expression - Lag(WSET1.expression) Over(Order By WSET1.expression Asc) as timeToStartSubtractionLagTimeToStartOverOrderByTimeToStartAsc
    From ScheduleTable As ST1
    Inner Join EpochTimeTable As ETT1
    On ST1.timeToStart = ETT1.id
    Inner Join NumberTable As NT1
    On ETT1.epochTime = NT1.id
    Inner Join ExpressionMeaningTable As EMT1
    On NT1.numeral = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Inner Join LocationTaskTable As LTT1
    On ST1.eventOrTask = LTT1.id
    Inner Join LocationTable As LT1
    On LTT1.location = LT1.id
    Inner Join ExpressionMeaningTable As EMT2
    On LT1.name = EMT2.meaning
    Inner Join WritingSystemExpressionTable As WSET2
    On EMT2.expression = WSET2.id
    Inner Join Program01ClassFunctionTaskTable As P01CFTT1
    On LTT1.id = P01CFTT1.id
    Inner Join ExpressionMeaningTable As EMT3
    On ST1.result = EMT3.meaning
    Inner Join WritingSystemExpressionTable As WSET3
    On EMT3.expression = WSET3.id
    Where WSET2.expression = :location And WSET3.expression = :result And P01CFTT1.name = :functionName
    Order by ST1.id Desc Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['location' => $this->location, 'result' => $this->result, 'functionName' => $this->functionName]);
    $stmt->fetchAll(\PDO::FETCH_FUNC, function($timeToStartSubtractionLagTimeToStartOverOrderByTimeToStartAsc){$this->differenceBetweentTmeToStart = $timeToStartSubtractionLagTimeToStartOverOrderByTimeToStartAsc;});
  }

}
