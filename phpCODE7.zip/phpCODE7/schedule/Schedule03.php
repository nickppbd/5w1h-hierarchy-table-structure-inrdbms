<?php

namespace weatherpi\schedule;

use \weatherpi\what\What001;
use \weatherpi\weatherpiTrait\endedTime_privateTrait;
use \weatherpi\weatherpiTrait\Set_endedTime3Trait;
use \weatherpi\weatherpiTrait\timeToStart_privateTrait;
use \weatherpi\weatherpiTrait\Set_timeToStart2Trait;
use \weatherpi\weatherpiTrait\location_privateTrait;
use \weatherpi\weatherpiTrait\Set_location4Trait;
use \weatherpi\epochTime\EpochTime01;
use \weatherpi\epochTime\EpochTime02;
use \weatherpi\weatherpiTrait\Result_privateTrait;
use \weatherpi\weatherpiTrait\Set_result4Trait;
use \weatherpi\expressionMeaningLanguage\ExpressionMeaningLanguage01;
use \weatherpi\weatherpiTrait\Set_functionName4Trait;
use \weatherpi\task\Task02;
use \weatherpi\weatherpiTrait\functionName_privateTrait;
use \weatherpi\weatherpiTrait\Get_functionName4Trait;
use \weatherpi\weatherpiTrait\Get_location4Trait;
use \weatherpi\weatherpiTrait\Get_timeToStart2Trait;

class Schedule03 extends What001 {
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $sql = 'Select ST1.id As id From ScheduleTable As ST1
    Inner Join EpochTimeTable As ETT1
    On ST1.timeToStart = ETT1.id
    Inner Join NumberTable As NT1
    On ETT1.epochTime = NT1.id
    Inner Join ExpressionMeaningTable As EMT1
    On NT1.numeral = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Inner Join LocationTaskTable As LTT1
    On ST1.eventOrTask = LTT1.id
    Inner Join LocationTable As LT1
    On LTT1.location = LT1.id
    Inner Join ExpressionMeaningTable As EMT2
    On LT1.name = EMT2.meaning
    Inner Join WritingSystemExpressionTable As WSET2
    On EMT2.expression = WSET2.id
    Inner Join Program01ClassFunctionTaskTable As P01CFTT1
    On LTT1.id = P01CFTT1.id
    Inner Join ExpressionMeaningTable As EMT3
    On ST1.result = EMT3.meaning
    Inner Join WritingSystemExpressionTable As WSET3
    On EMT3.expression = WSET3.id
    Where WSET1.expression = :timeToStart And WSET2.expression = :location And 
    WSET3.expression = :result And P01CFTT1.name = :functionName Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['timeToStart' => $this->timeToStart, 'location' => $this->location, 'result' => $this->result, 'functionName' => $this->functionName]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){return $id;});
    return $result;
  }

  private function create_newData()
  {
    $time = new EpochTime01();
    $time->set_epochTime2($this->timeToStart);
    $time->set_pdo0001($this->pdo);
    $task = new Task02();
    $task->set_location4($this->location);
    $task->set_functionName4($this->functionName);
    $task->set_pdo0001($this->pdo);
    $time2 = new EpochTime02();
    $time2->set_epochTime3($this->endedTime);
    $time2->set_pdo0001($this->pdo);
    $expressionMeaningLanguage = new ExpressionMeaningLanguage01();
    $expressionMeaningLanguage->set_expression4($this->result); 
    $expressionMeaningLanguage->set_language4('english'); 
    $expressionMeaningLanguage->set_pdo0001($this->pdo);
    $expressionMeaningLanguage->create_data();
    $sql = 'Insert Into ScheduleTable (id, timeToStart, eventOrTask, result) Values (:id, :timeToStart, :eventOrTask, :result);';
    $stmt= $this->pdo->prepare($sql);
    $sql2 = 'Insert Into EndedTimeScheduleTable (id, endedTime) Values (:id, :endedTime);';
    $stmt2= $this->pdo->prepare($sql2);
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId, 'timeToStart' => $time->create_data(), 'eventOrTask' => $task->create_data(), 'result' => $expressionMeaningLanguage->get_meaningId2()]);
    $stmt2->execute(['id' => $this->topNodeTableId, 'endedTime' => $time2->create_data()]);
    return $this->topNodeTableId;
  }

  use endedTime_privateTrait;
  use Set_endedTime3Trait;
  use timeToStart_privateTrait;
  use Set_timeToStart2Trait;
  use location_privateTrait;
  use Set_location4Trait;
  use Result_privateTrait;
  use Set_result4Trait;
  use functionName_privateTrait;
  use Set_functionName4Trait;
  use Get_functionName4Trait;
  use Get_location4Trait;
  use Get_timeToStart2Trait;
}
