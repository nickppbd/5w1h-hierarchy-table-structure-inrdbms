<?php

namespace weatherpi\task;

use \weatherpi\what\What001;
use \weatherpi\weatherpiTrait\location_privateTrait;
use \weatherpi\weatherpiTrait\Set_location4Trait;
use \weatherpi\location\Location01;
use \weatherpi\weatherpiTrait\functionName_privateTrait;
use \weatherpi\weatherpiTrait\Set_functionName4Trait;

class Task02 extends What001 {
  use location_privateTrait;
  use Set_location4Trait;
  use functionName_privateTrait;
  use Set_functionName4Trait;
  public function create_data()
  {
    if(!empty($id = $this->does_exist())) {
        return $id[0];    
    } else  {
        return $this->create_newData();
    }
  }

  public function does_exist()
  {
    $sql = 'Select LTT1.id As id From LocationTaskTable As LTT1
    Inner Join LocationTable As LT1
    On LTT1.location = LT1.id
    Inner Join ExpressionMeaningTable As EMT1
    On LT1.name = EMT1.meaning
    Inner Join WritingSystemExpressionTable As WSET1
    On EMT1.expression = WSET1.id
    Inner Join Program01ClassFunctionTaskTable As P01CFTT1
    On LTT1.id = P01CFTT1.id
    Where WSET1.expression = :location And P01CFTT1.name = :functionName Limit 1 For Update;';
    $stmt= $this->pdo->prepare($sql);
    $stmt->execute(['location' => $this->location, 'functionName' => $this->functionName]);
    $result = $stmt->fetchAll(\PDO::FETCH_FUNC, function($id){return $id;});
    return $result;
  }

  private function create_newData()
  {
    $location = new Location01();
    $location->set_name4($this->location);
    $location->set_pdo0001($this->pdo);
    $stmt= $this->pdo->prepare('Insert Into TaskTable (id) Values (:id);');
    $stmt2= $this->pdo->prepare('Insert Into LocationTaskTable (id, location) Values (:id, :location);');
    $stmt3= $this->pdo->prepare('Insert Into Program01ClassFunctionTaskTable (id, name) Values (:id, :name);');
    parent::create_data();
    $stmt->execute(['id' => $this->topNodeTableId]);
    $stmt2->execute(['id' => $this->topNodeTableId, 'location' => $location->create_data()]);
    $stmt3->execute(['id' => $this->topNodeTableId, 'name' => $this->functionName]);
    return $this->topNodeTableId;
  }

}
