<?php

namespace weatherpi\how;

use \weatherpi\topNode\TopNode01;
use \weatherpi\weatherpiTrait\Get_sql_InsertIntoHowTableIdValuesIdTrait;
use \weatherpi\weatherpiTrait\Prepare_sql_and_parent_create_data_and_bindValue_and_execute_by_PDOTrait;

abstract class How001 extends TopNode01 {
use Get_sql_InsertIntoHowTableIdValuesIdTrait {
	get_sql_InsertIntoHowTableIdValuesId as get_sql;
}
use Prepare_sql_and_parent_create_data_and_bindValue_and_execute_by_PDOTrait {
	prepare_sql_and_parent_create_data_and_bindValue_and_execute_by_PDO as public create_data;
}
}
